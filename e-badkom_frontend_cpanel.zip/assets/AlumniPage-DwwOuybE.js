import{t as e}from"./useQuery-pglRwBmA.js";import{t}from"./TablePagination-C8J5xpJ1.js";import{t as n}from"./printer-BZeRanSr.js";import{t as r}from"./search-Del4_KQJ.js";import{I as i,L as a,g as o,h as s,t as c,v as l}from"./index-BttRe-zx.js";var u=s(`graduation-cap`,[[`path`,{d:`M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z`,key:`j76jl0`}],[`path`,{d:`M22 10v6`,key:`1lu8f3`}],[`path`,{d:`M6 12.5V16a6 3 0 0 0 12 0v-3.5`,key:`1r8lef`}]]),d=a(i(),1),f=l(),p=()=>{let[i,a]=(0,d.useState)(``),[s,l]=(0,d.useState)(1),[p,m]=(0,d.useState)(10),{data:h=[],isLoading:g}=e({queryKey:[`alumni`],queryFn:async()=>(await c.get(`/santri?status=Alumni`)).data}),_=h.filter(e=>e.nama.toLowerCase().includes(i.toLowerCase())||e.nis.toLowerCase().includes(i.toLowerCase())),v=Math.ceil(_.length/p),y=_.slice((s-1)*p,s*p);return d.useEffect(()=>{l(1)},[i]),(0,f.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`24px`,animation:`fadeIn 0.5s ease`},children:[(0,f.jsx)(`style`,{children:`
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        
        .page-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          flex-wrap: wrap;
          gap: 16px;
          background: #ffffff;
          padding: 16px 20px;
          border-radius: 16px;
          box-shadow: 0 4px 20px rgba(0,0,0,0.03);
          border: 1px solid #f1f5f9;
        }

        .search-container {
          position: relative;
          width: 320px;
        }
        
        .search-input {
          width: 100%;
          padding: 8px 16px 8px 40px;
          border-radius: 30px;
          border: 1px solid #e2e8f0;
          background: #f8fafc;
          transition: all 0.3s ease;
          font-size: 0.95rem;
        }
        
        .search-input:focus {
          background: #ffffff;
          border-color: var(--secondary);
          box-shadow: 0 0 0 4px rgba(0, 143, 215, 0.1);
          outline: none;
        }

        .data-table-container {
          background: #ffffff;
          border-radius: 16px;
          box-shadow: 0 4px 20px rgba(0,0,0,0.03);
          border: 1px solid #f1f5f9;
          overflow-y: hidden;
          overflow-x: auto;
        }

        .data-table {
          width: 100%;
          min-width: 800px;
          border-collapse: collapse;
          text-align: left;
        }

        .data-table th {
          padding: 18px 24px;
          font-weight: 600;
          color: #64748b;
          background: #f8fafc;
          border-bottom: 1px solid #e2e8f0;
          text-transform: uppercase;
          font-size: 0.75rem;
          letter-spacing: 0.05em;
        }

        .data-table td {
          padding: 16px 24px;
          border-bottom: 1px solid #f1f5f9;
          transition: background 0.2s ease;
          vertical-align: middle;
        }

        .data-table tbody tr {
          transition: all 0.2s ease;
        }

        .data-table tbody tr:hover {
          background: #f8fafc;
          transform: scale(1.001);
        }
      `}),(0,f.jsxs)(`div`,{className:`flex flex-col md:flex-row justify-between items-center gap-4 bg-white p-5 rounded-2xl shadow-[0_4px_20px_rgba(0,0,0,0.03)] border border-slate-100`,children:[(0,f.jsxs)(`div`,{className:`flex items-center gap-3 w-full md:w-auto`,children:[(0,f.jsx)(`div`,{className:`p-2 bg-green-50 text-green-600 rounded-xl`,children:(0,f.jsx)(u,{size:24})}),(0,f.jsxs)(`h2`,{className:`m-0 text-xl text-slate-900 font-bold`,children:[`Daftar Alumni `,(0,f.jsx)(`span`,{className:`text-slate-400 text-base font-medium`,children:`(Purna Tugas)`})]})]}),(0,f.jsxs)(`div`,{className:`relative w-full md:w-80`,children:[(0,f.jsx)(`div`,{className:`absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none`,children:(0,f.jsx)(r,{size:20,className:`text-slate-400`})}),(0,f.jsx)(`input`,{type:`text`,className:`w-full pl-10 pr-4 py-2 rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-4 focus:ring-[#008FD7]/10 focus:border-[#008FD7] transition-all text-sm`,placeholder:`Cari alumni...`,value:i,onChange:e=>a(e.target.value)})]})]}),(0,f.jsxs)(`div`,{className:`data-table-container`,children:[(0,f.jsxs)(`table`,{className:`data-table`,children:[(0,f.jsx)(`thead`,{children:(0,f.jsxs)(`tr`,{children:[(0,f.jsx)(`th`,{children:`Santri`}),(0,f.jsx)(`th`,{children:`Nomor Surat Kelulusan`}),(0,f.jsx)(`th`,{children:`Tanggal Lulus`}),(0,f.jsx)(`th`,{className:`text-right`,children:`Aksi`})]})}),(0,f.jsx)(`tbody`,{children:g?(0,f.jsx)(`tr`,{children:(0,f.jsx)(`td`,{colSpan:4,style:{padding:`40px`,textAlign:`center`,color:`var(--text-secondary)`},children:`Memuat data...`})}):y.length===0?(0,f.jsx)(`tr`,{children:(0,f.jsx)(`td`,{colSpan:4,style:{padding:`40px`,textAlign:`center`,color:`var(--text-secondary)`},children:`Tidak ada data alumni.`})}):y.map(e=>(0,f.jsxs)(`tr`,{children:[(0,f.jsxs)(`td`,{children:[(0,f.jsx)(`div`,{style:{fontWeight:600,color:`#0f172a`},children:e.nama}),(0,f.jsxs)(`div`,{style:{fontSize:`0.875rem`,color:`#64748b`},children:[`NIS: `,e.nis]})]}),(0,f.jsx)(`td`,{children:(0,f.jsx)(`span`,{style:{fontWeight:600,color:`#0369a1`,background:`#e0f2fe`,padding:`4px 12px`,borderRadius:`20px`,fontSize:`0.85rem`},children:e.boyong?.no_surat||`-`})}),(0,f.jsx)(`td`,{style:{color:`#475569`,fontWeight:500},children:e.boyong?.tanggal_lulus?new Date(e.boyong.tanggal_lulus).toLocaleDateString(`id-ID`):`-`}),(0,f.jsx)(`td`,{className:`text-right`,children:(0,f.jsxs)(`button`,{className:`btn btn-primary`,style:{padding:`8px 16px`,borderRadius:`30px`,display:`inline-flex`,alignItems:`center`,gap:`8px`,boxShadow:`0 4px 12px rgba(66, 47, 111, 0.2)`},onClick:async()=>{try{let t=await c.get(`/cetak/surat-lulus-tugas/${e.id}`,{responseType:`blob`,skipToast:!0}),n=URL.createObjectURL(new Blob([t.data],{type:`application/pdf`}));window.open(n,`_blank`)}catch{o.error(`Gagal memuat PDF`)}},children:[(0,f.jsx)(n,{size:16}),` Cetak Surat`]})})]},e.id))})]}),!g&&(0,f.jsx)(t,{currentPage:s,totalPages:v,totalItems:_.length,itemsPerPage:p,onPageChange:l,onItemsPerPageChange:e=>{m(e),l(1)}})]})]})};export{p as default};