import{t as e}from"./useQuery-Bi5XVxXO.js";import{t}from"./useMutation-B57Xzg0j.js";import{t as n}from"./TablePagination-DLh7OhnX.js";import{t as r}from"./map-pin-GSUNndZz.js";import{t as i}from"./pen-Dk5v2XMV.js";import{t as a}from"./printer-89QkqrR4.js";import{t as o}from"./search-Bpg5xGQp.js";import{t as s}from"./trash-2-DxC0bQEI.js";import{I as c,L as l,_ as u,g as d,i as f,r as p,t as m,v as h}from"./index-C-TRLpB4.js";import{t as g}from"./SearchableSelect-9g1ArCsf.js";var _=l(c(),1),v=h(),y=()=>{let{showConfirm:c}=p(),l=u(),[h,y]=(0,_.useState)(!1),[b,x]=(0,_.useState)(``),[S,C]=(0,_.useState)(``),[w,T]=(0,_.useState)({santri_ids:[void 0],pjutd_id:void 0}),[E,D]=(0,_.useState)(``),[O,k]=(0,_.useState)(!1),[A,j]=(0,_.useState)(1),[M,N]=(0,_.useState)(10),P=localStorage.getItem(`user`),F=(P?JSON.parse(P):null)?.level===`badkom_wilayah`,{data:I=[]}=e({queryKey:[`tahun-ajaran`],queryFn:async()=>(await m.get(`/tahun-ajaran`)).data}),{data:L=[],isLoading:R}=e({queryKey:[`utd`,S],queryFn:async()=>{let e=S?{tahun_ajaran_id:S}:{};return(await m.get(`/utd`,{params:e})).data}}),{data:z=[]}=e({queryKey:[`santri-list`],queryFn:async()=>(await m.get(`/santri`)).data}),{data:B=[]}=e({queryKey:[`pjutd-list`],queryFn:async()=>(await m.get(`/pjutd`)).data}),V=t({mutationFn:e=>m.delete(`/utd/${e}`),onSuccess:()=>{l.invalidateQueries({queryKey:[`utd`]})},onError:()=>{d.error(`Gagal menghapus penugasan.`)}}),H=async e=>{if(e.preventDefault(),!w.pjutd_id||w.santri_ids.some(e=>!e)){D(`Semua field Santri dan PJ UTD harus diisi`);return}k(!0),D(``);try{w.id?await m.put(`/utd/${w.id}`,{santri_id:w.santri_ids[0],pjutd_id:w.pjutd_id}):await Promise.all(w.santri_ids.map(e=>m.post(`/utd`,{santri_id:e,pjutd_id:w.pjutd_id}))),l.invalidateQueries({queryKey:[`utd`]}),y(!1),T({santri_ids:[void 0],pjutd_id:void 0}),d.success(`Penugasan berhasil disimpan`)}catch(e){D(e.response?.data?.message||`Gagal menyimpan penugasan. Pastikan santri belum ditugaskan di tempat lain.`)}finally{k(!1)}},U=L.filter(e=>e.santri?.nama.toLowerCase().includes(b.toLowerCase())||e.santri?.nis.toLowerCase().includes(b.toLowerCase())||e.pjutd?.nama_pjutd.toLowerCase().includes(b.toLowerCase())||(e.pjutd?.nama_madrasah||``).toLowerCase().includes(b.toLowerCase())||(e.pjutd?.yayasan||``).toLowerCase().includes(b.toLowerCase())),W=Math.ceil(U.length/M),G=U.slice((A-1)*M,A*M);return _.useEffect(()=>{j(1)},[b,S]),(0,v.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`24px`,animation:`fadeIn 0.5s ease`},children:[(0,v.jsx)(`style`,{children:`
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        
        .page-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          flex-wrap: wrap;
          gap: 16px;
          background: #ffffff;
          padding: 16px 20px;
          border-radius: 16px;
          box-shadow: 0 4px 20px rgba(0,0,0,0.03);
          border: 1px solid #f1f5f9;
        }

        .search-container {
          position: relative;
          width: 320px;
        }
        
        .search-input {
          width: 100%;
          padding: 8px 16px 8px 40px;
          border-radius: 30px;
          border: 1px solid #e2e8f0;
          background: #f8fafc;
          transition: all 0.3s ease;
          font-size: 0.95rem;
        }
        
        .search-input:focus {
          background: #ffffff;
          border-color: var(--secondary);
          box-shadow: 0 0 0 4px rgba(0, 143, 215, 0.1);
          outline: none;
        }

        .action-buttons {
          display: flex;
          gap: 12px;
          flex-wrap: nowrap;
          align-items: center;
        }

        .data-table-container {
          background: #ffffff;
          border-radius: 16px;
          box-shadow: 0 4px 20px rgba(0,0,0,0.03);
          border: 1px solid #f1f5f9;
          overflow-y: hidden;
          overflow-x: auto;
        }

        .data-table {
          width: 100%;
          min-width: 800px;
          border-collapse: collapse;
          text-align: left;
        }

        .data-table th {
          padding: 18px 24px;
          font-weight: 600;
          color: #64748b;
          background: #f8fafc;
          border-bottom: 1px solid #e2e8f0;
          text-transform: uppercase;
          font-size: 0.75rem;
          letter-spacing: 0.05em;
        }

        .data-table td {
          padding: 16px 24px;
          border-bottom: 1px solid #f1f5f9;
          transition: background 0.2s ease;
          vertical-align: middle;
        }

        .data-table tbody tr {
          transition: all 0.2s ease;
        }

        .data-table tbody tr:hover {
          background: #f8fafc;
          transform: scale(1.001);
        }

        .action-btn {
          border: none;
          background: none;
          cursor: pointer;
          width: 36px;
          height: 36px;
          border-radius: 50%;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }

        .action-btn.edit { color: #64748b; }
        .action-btn.edit:hover { background: #f1f5f9; color: #0f172a; }

        .action-btn.delete { color: #ef4444; }
        .action-btn.delete:hover { background: #fee2e2; }
      `}),(0,v.jsxs)(`div`,{className:`flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 bg-white p-5 rounded-2xl shadow-[0_4px_20px_rgba(0,0,0,0.03)] border border-slate-100`,children:[(0,v.jsxs)(`div`,{className:`relative w-full lg:w-80`,children:[(0,v.jsx)(`div`,{className:`absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none`,children:(0,v.jsx)(o,{size:20,className:`text-slate-400`})}),(0,v.jsx)(`input`,{type:`text`,className:`w-full pl-10 pr-4 py-2 rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-4 focus:ring-[#008FD7]/10 focus:border-[#008FD7] transition-all text-sm`,placeholder:`Cari penugasan...`,value:b,onChange:e=>x(e.target.value)})]}),(0,v.jsxs)(`div`,{className:`flex flex-wrap items-center gap-3 w-full lg:w-auto`,children:[(0,v.jsxs)(`select`,{value:S,onChange:e=>C(e.target.value),className:`w-full md:w-auto min-w-[200px] rounded-full px-4 py-2 border border-slate-200 bg-slate-50 text-sm text-slate-700 focus:outline-none focus:ring-4 focus:ring-[#008FD7]/10 focus:border-[#008FD7] transition-all cursor-pointer`,children:[(0,v.jsx)(`option`,{value:``,children:`Tahun Ajaran Aktif`}),I.map(e=>(0,v.jsxs)(`option`,{value:e.id,children:[e.nama_tahun_ajaran,` `,e.is_active?`(Aktif)`:`(Arsip)`]},e.id))]}),(0,v.jsxs)(`button`,{className:`flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2 rounded-lg text-sm font-semibold transition-all w-full md:w-auto border border-slate-200`,onClick:async()=>{try{let e=`/cetak/penugasan${S?`?tahun_ajaran_id=`+S:``}`,t=await m.get(e,{responseType:`blob`,skipToast:!0}),n=new Blob([t.data],{type:`application/pdf`}),r=URL.createObjectURL(n);window.open(r,`_blank`)}catch{d.error(`Gagal membuat PDF`)}},children:[(0,v.jsx)(a,{size:16}),`Cetak Penempatan`]}),!F&&(0,v.jsxs)(`button`,{className:`flex items-center gap-2 bg-[#422F6F] hover:bg-[#1e293b] text-white px-4 py-2 rounded-lg text-sm font-medium transition-all shadow-sm hover:shadow w-full md:w-auto justify-center`,onClick:()=>{T({santri_ids:[void 0],pjutd_id:void 0}),y(!0),D(``)},children:[(0,v.jsx)(r,{size:16}),`Tambah Penugasan`]})]})]}),(0,v.jsxs)(`div`,{className:`data-table-container`,children:[(0,v.jsxs)(`table`,{className:`data-table`,children:[(0,v.jsx)(`thead`,{children:(0,v.jsxs)(`tr`,{children:[(0,v.jsx)(`th`,{children:`Santri`}),(0,v.jsx)(`th`,{children:`Lokasi PJ UTD`}),(0,v.jsx)(`th`,{children:`Tahun Ajaran`}),!F&&(0,v.jsx)(`th`,{className:`text-right`,children:`Aksi`})]})}),(0,v.jsx)(`tbody`,{children:R?(0,v.jsx)(`tr`,{children:(0,v.jsx)(`td`,{colSpan:4,style:{padding:`40px`,textAlign:`center`,color:`var(--text-secondary)`},children:`Memuat data...`})}):G.length===0?(0,v.jsx)(`tr`,{children:(0,v.jsx)(`td`,{colSpan:4,style:{padding:`40px`,textAlign:`center`,color:`var(--text-secondary)`},children:`Belum ada data penugasan`})}):G.map(e=>(0,v.jsxs)(`tr`,{children:[(0,v.jsxs)(`td`,{children:[(0,v.jsx)(`div`,{style:{fontWeight:600,color:`#0f172a`},children:e.santri?.nama}),(0,v.jsxs)(`div`,{style:{fontSize:`0.85rem`,color:`#64748b`},children:[`NIS: `,e.santri?.nis]})]}),(0,v.jsxs)(`td`,{children:[(0,v.jsx)(`div`,{style:{fontWeight:600,color:`#0f172a`},children:e.pjutd?.nama_madrasah||e.pjutd?.yayasan||e.pjutd?.nama_pjutd}),(0,v.jsxs)(`div`,{style:{fontSize:`0.85rem`,color:`#64748b`},children:[`Kode: `,e.pjutd?.kode_lembaga]})]}),(0,v.jsxs)(`td`,{children:[(0,v.jsx)(`div`,{style:{fontWeight:600,color:`#334155`},children:e.tahun_ajaran?.nama_tahun_ajaran}),e.tahun_ajaran&&!e.tahun_ajaran.is_active&&(0,v.jsx)(`span`,{style:{fontSize:`0.75rem`,background:`#f1f5f9`,color:`#64748b`,padding:`2px 8px`,borderRadius:`12px`,border:`1px solid #e2e8f0`,marginTop:`4px`,display:`inline-block`},children:`Arsip`})]}),!F&&(0,v.jsx)(`td`,{className:`text-right`,children:(0,v.jsxs)(`div`,{style:{display:`flex`,gap:`4px`,justifyContent:`flex-end`},children:[(0,v.jsx)(`button`,{className:`action-btn edit`,onClick:()=>{T({id:e.id,santri_ids:[e.santri_id],pjutd_id:e.pjutd_id}),y(!0),D(``)},title:`Edit Penugasan`,children:(0,v.jsx)(i,{size:18})}),(0,v.jsx)(`button`,{className:`action-btn delete`,onClick:()=>{c(`Apakah Anda yakin ingin menghapus penugasan ini?`,()=>{V.mutate(e.id)})},title:`Hapus Penugasan`,children:(0,v.jsx)(s,{size:18})})]})})]},e.id))})]}),!R&&(0,v.jsx)(n,{currentPage:A,totalPages:W,totalItems:U.length,itemsPerPage:M,onPageChange:j,onItemsPerPageChange:e=>{N(e),j(1)}})]}),(0,v.jsx)(f,{isOpen:h,onClose:()=>y(!1),title:w.id?`Edit Penugasan`:`Tambah Penugasan`,overflowVisible:!0,children:(0,v.jsxs)(`form`,{onSubmit:H,style:{display:`flex`,flexDirection:`column`,gap:`16px`},children:[E&&(0,v.jsx)(`div`,{style:{padding:`12px`,background:`#fef2f2`,color:`#ef4444`,borderRadius:`6px`,fontSize:`0.875rem`},children:E}),(0,v.jsxs)(`div`,{style:{background:`#f8fafc`,padding:`24px`,borderRadius:`16px`,border:`1px solid #e2e8f0`,display:`flex`,flexDirection:`column`,gap:`16px`},children:[w.santri_ids.map((e,t)=>(0,v.jsxs)(`div`,{className:`form-group`,style:{marginBottom:0},children:[(0,v.jsxs)(`label`,{className:`form-label`,children:[`Santri `,w.santri_ids.length>1?t+1:``]}),(0,v.jsxs)(`div`,{style:{display:`flex`,gap:`8px`},children:[(0,v.jsx)(`div`,{style:{flex:1},children:(0,v.jsx)(g,{options:z.filter(t=>!L.some(e=>e.santri_id===t.id)||t.id===e).map(e=>({value:e.id,label:`${e.nis} - ${e.nama}`})),value:e,onChange:e=>{let n=[...w.santri_ids];n[t]=Number(e),T({...w,santri_ids:n})},placeholder:`-- Cari dan Pilih Santri --`,required:!0})}),!w.id&&w.santri_ids.length>1&&(0,v.jsx)(`button`,{type:`button`,className:`btn`,style:{background:`#fef2f2`,color:`#ef4444`,padding:`0 12px`},onClick:()=>{let e=[...w.santri_ids];e.splice(t,1),T({...w,santri_ids:e})},children:(0,v.jsx)(s,{size:18})})]})]},t)),!w.id&&(0,v.jsx)(`button`,{type:`button`,className:`btn`,style:{background:`#ffffff`,border:`1px dashed #cbd5e1`,color:`#475569`,alignSelf:`flex-start`,fontSize:`0.875rem`},onClick:()=>{T({...w,santri_ids:[...w.santri_ids,void 0]})},children:`+ Tambah Santri Lain`}),(0,v.jsxs)(`div`,{className:`form-group`,style:{marginBottom:0,marginTop:`8px`},children:[(0,v.jsx)(`label`,{className:`form-label`,children:`PJ UTD (Lokasi Tugas)`}),(0,v.jsx)(g,{options:B.map(e=>({value:e.id,label:`${e.kode_lembaga} - ${e.nama_madrasah||e.yayasan||e.nama_pjutd}`})),value:w.pjutd_id,onChange:e=>T({...w,pjutd_id:Number(e)}),placeholder:`-- Cari dan Pilih PJ UTD --`,required:!0})]})]}),(0,v.jsxs)(`div`,{style:{display:`flex`,gap:`12px`,justifyContent:`flex-end`,marginTop:`8px`},children:[(0,v.jsx)(`button`,{type:`button`,className:`btn`,onClick:()=>y(!1),children:`Batal`}),(0,v.jsx)(`button`,{type:`submit`,className:`btn btn-primary`,disabled:O,children:O?`Menyimpan...`:`Simpan`})]})]})})]})};export{y as default};