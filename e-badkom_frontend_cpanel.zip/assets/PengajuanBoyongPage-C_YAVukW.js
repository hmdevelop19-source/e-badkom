import{t as e}from"./useQuery-pglRwBmA.js";import{t}from"./useMutation-CGep55OV.js";import{t as n}from"./circle-alert-DMPwasKl.js";import{t as r}from"./circle-check-big-B8gZywhV.js";import{t as i}from"./plus-AmnPqCe6.js";import{t as a}from"./trash-2-B0D5ZvXT.js";import{I as o,L as s,_ as c,d as l,h as u,t as d,v as f}from"./index-BttRe-zx.js";import{t as p}from"./SearchableSelect-RrDOvCoh.js";var m=u(`send`,[[`path`,{d:`M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z`,key:`1ffxy3`}],[`path`,{d:`m21.854 2.147-10.94 10.939`,key:`12cjpa`}]]),h=s(o(),1),g=f(),_=()=>{let o=c(),[s,u]=(0,h.useState)(`reguler`),[f,_]=(0,h.useState)(``),[v,y]=(0,h.useState)(``),[b,x]=(0,h.useState)(``),[S,C]=(0,h.useState)(``),[w,T]=(0,h.useState)(``),[E,D]=(0,h.useState)(``),[O,k]=(0,h.useState)(``),[A,j]=(0,h.useState)(``),[M,N]=(0,h.useState)(``),[P,F]=(0,h.useState)(``),[I,L]=(0,h.useState)([{pjutd_id:``,tahun_pendidikan:``,nilai:`B`}]),[R,z]=(0,h.useState)(``),[B,V]=(0,h.useState)(``),[H,U]=(0,h.useState)(null),{data:W=[]}=e({queryKey:[`pjutds`],queryFn:async()=>(await d.get(`/pjutd`)).data}),G=W.map(e=>({value:e.id,label:`${e.nama_pjutd} (${e.kecamatan?.nama||`-`})`})),K=t({mutationFn:e=>d.post(`/boyong`,e),onSuccess:e=>{o.invalidateQueries({queryKey:[`santri`]}),o.invalidateQueries({queryKey:[`boyong-menunggu`]}),U({type:`success`,text:e.data.message||`Pengajuan boyong berhasil dikirim.`}),_(``),y(``),x(``),C(``)},onError:e=>{U({type:`error`,text:e.response?.data?.message||`Terjadi kesalahan saat mengajukan boyong.`})}}),q=t({mutationFn:e=>d.post(`/boyong/manual`,e),onSuccess:e=>{o.invalidateQueries({queryKey:[`santri`]}),o.invalidateQueries({queryKey:[`boyong`]}),U({type:`success`,text:e.data.message||`Data alumni manual berhasil ditambahkan dan SKL telah di-generate.`}),T(``),D(``),k(``),j(``),N(``),F(``),L([{pjutd_id:``,tahun_pendidikan:``,nilai:`B`}]),z(``),V(``)},onError:e=>{U({type:`error`,text:e.response?.data?.message||`Terjadi kesalahan saat menyimpan data alumni manual.`})}}),J=e=>{if(e.preventDefault(),!f.trim()){U({type:`error`,text:`NIS tidak boleh kosong.`});return}K.mutate({nis:f,tahun_mondok:v,tahun_tugas:b,keterangan:S})},Y=e=>{e.preventDefault();let t=I.filter(e=>e.pjutd_id!==``&&e.tahun_pendidikan!==``);if(!w.trim()||!E.trim()||t.length===0){U({type:`error`,text:`NIS, Nama, dan minimal satu Lembaga Tugas (beserta Tahun Pendidikan) wajib diisi.`});return}q.mutate({nis:w,nama:E,tempat_lahir:O,tanggal_lahir:A,nama_wali:M,alamat:P,pjutd_data:t,tahun_mondok:R,tahun_tugas:B})},X=()=>{L([...I,{pjutd_id:``,tahun_pendidikan:``,nilai:`B`}])},Z=e=>{if(I.length>1){let t=[...I];t.splice(e,1),L(t)}},Q=(e,t,n)=>{let r=[...I];r[e]={...r[e],[t]:n},L(r)};return(0,g.jsxs)(g.Fragment,{children:[(0,g.jsx)(`style`,{children:`
        .boyong-tab-btn {
          padding: 12px 24px;
          border-radius: 14px;
          border: none;
          display: flex;
          align-items: center;
          gap: 10px;
          font-weight: 600;
          font-size: 0.9rem;
          cursor: pointer;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          background: transparent;
          color: #64748b;
          white-space: nowrap;
        }
        .boyong-tab-btn:hover:not(.active) {
          background: rgba(226, 232, 240, 0.5);
          color: #334155;
        }
        .boyong-tab-btn.active.reguler {
          background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
          color: white;
          box-shadow: 0 4px 15px rgba(79, 70, 229, 0.3);
        }
        .boyong-tab-btn.active.manual {
          background: linear-gradient(135deg, #0ea5e9 0%, #2563eb 100%);
          color: white;
          box-shadow: 0 4px 15px rgba(14, 165, 233, 0.3);
        }
        .boyong-card-header {
          background: white;
          border-radius: 24px;
          padding: 32px;
          box-shadow: 0 10px 40px -10px rgba(15, 23, 42, 0.08);
          border: 1px solid rgba(226, 232, 240, 0.8);
          position: relative;
          overflow: hidden;
        }
        .boyong-card-header::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 6px;
          background: linear-gradient(90deg, #4f46e5, #ec4899);
          opacity: 0.8;
          transition: all 0.5s ease;
        }
        .boyong-card-header.manual-mode::before {
          background: linear-gradient(90deg, #0ea5e9, #2563eb);
        }
        .form-section-title {
          font-size: 0.95rem;
          font-weight: 700;
          color: var(--primary);
          margin-bottom: 16px;
          padding-bottom: 8px;
          border-bottom: 2px solid #f1f5f9;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .pjutd-card {
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 16px;
          padding: 20px;
          transition: all 0.3s ease;
          position: relative;
        }
        .pjutd-card:hover {
          border-color: #cbd5e1;
          box-shadow: 0 4px 12px rgba(0,0,0,0.02);
        }
        .boyong-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 20px;
        }
        .styled-input {
          width: 100%;
          padding: 12px 16px;
          border-radius: 12px;
          border: 1px solid #cbd5e1;
          background: #ffffff;
          font-size: 0.95rem;
          color: #334155;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          box-shadow: 0 1px 2px rgba(0,0,0,0.02);
        }
        .styled-input:focus {
          outline: none;
          border-color: #4f46e5;
          box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.15);
          background: #f8fafc;
        }
        .styled-input::placeholder {
          color: #94a3b8;
        }
        .manual-mode .styled-input:focus {
          border-color: #0ea5e9;
          box-shadow: 0 0 0 3px rgba(14, 165, 233, 0.15);
        }

        @media (max-width: 768px) {
          .boyong-grid {
            grid-template-columns: 1fr;
          }
          .boyong-card-header {
            padding: 24px 20px;
          }
        }
      `}),(0,g.jsxs)(`div`,{className:`fade-in`,style:{display:`flex`,flexDirection:`column`,gap:`24px`,maxWidth:`900px`,margin:`0 auto`},children:[(0,g.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`20px`,alignItems:`center`,textAlign:`center`,marginBottom:`8px`},children:[(0,g.jsxs)(`div`,{children:[(0,g.jsx)(`div`,{style:{display:`inline-flex`,alignItems:`center`,justifyContent:`center`,width:`64px`,height:`64px`,borderRadius:`20px`,background:`linear-gradient(135deg, rgba(79, 70, 229, 0.1) 0%, rgba(124, 58, 237, 0.1) 100%)`,color:`var(--primary)`,marginBottom:`16px`},children:(0,g.jsx)(m,{size:32,strokeWidth:1.5})}),(0,g.jsx)(`h2`,{style:{margin:`0 0 8px 0`,fontSize:`1.75rem`,fontWeight:800,color:`var(--text-primary)`,letterSpacing:`-0.5px`},children:`Pengajuan Kelulusan Tugas`}),(0,g.jsx)(`p`,{style:{margin:0,color:`#64748b`,maxWidth:`500px`,lineHeight:1.5},children:`Proses administrasi kelulusan tugas akhir (Boyong) untuk UT-D aktif atau input data arsip bagi UT-D lama.`})]}),(0,g.jsxs)(`div`,{style:{display:`flex`,background:`#f8fafc`,padding:`8px`,borderRadius:`18px`,gap:`8px`,border:`1px solid #e2e8f0`,boxShadow:`0 4px 6px -1px rgba(0,0,0,0.02)`},children:[(0,g.jsxs)(`button`,{className:`boyong-tab-btn ${s===`reguler`?`active reguler`:``}`,onClick:()=>{u(`reguler`),U(null)},children:[(0,g.jsx)(m,{size:18}),` Pengajuan Reguler`]}),(0,g.jsxs)(`button`,{className:`boyong-tab-btn ${s===`manual`?`active manual`:``}`,onClick:()=>{u(`manual`),U(null)},children:[(0,g.jsx)(l,{size:18}),` Input Data Lama`]})]})]}),(0,g.jsxs)(`div`,{className:`boyong-card-header ${s===`manual`?`manual-mode`:``}`,children:[H&&(0,g.jsxs)(`div`,{style:{display:`flex`,alignItems:`flex-start`,gap:`12px`,padding:`16px 20px`,borderRadius:`12px`,marginBottom:`32px`,background:H.type===`success`?`#f0fdf4`:`#fef2f2`,color:H.type===`success`?`#166534`:`#991b1b`,border:`1px solid ${H.type===`success`?`#bbf7d0`:`#fecaca`}`,fontWeight:500,boxShadow:`0 4px 6px rgba(0,0,0,0.02)`},children:[(0,g.jsx)(`div`,{style:{marginTop:`2px`},children:H.type===`success`?(0,g.jsx)(r,{size:20}):(0,g.jsx)(n,{size:20})}),(0,g.jsx)(`div`,{style:{lineHeight:1.5},children:H.text})]}),s===`reguler`?(0,g.jsxs)(`form`,{onSubmit:J,style:{display:`flex`,flexDirection:`column`,gap:`28px`},children:[(0,g.jsxs)(`div`,{style:{background:`#f8fafc`,padding:`16px 20px`,borderRadius:`12px`,border:`1px dashed #cbd5e1`,color:`#475569`,fontSize:`0.9rem`,lineHeight:1.5},children:[(0,g.jsx)(`strong`,{style:{color:`var(--text-primary)`},children:`Panduan:`}),` Gunakan formulir ini untuk mengajukan kelulusan tugas (boyong) secara normal. Sistem akan memeriksa kelengkapan kewajiban tugas dan laporan secara otomatis sebelum menyetujui pengajuan.`]}),(0,g.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`8px`},children:[(0,g.jsx)(`label`,{style:{fontSize:`0.875rem`,fontWeight:600,color:`var(--text-primary)`},children:`NIS Santri *`}),(0,g.jsx)(`input`,{type:`text`,className:`styled-input`,value:f,onChange:e=>_(e.target.value),placeholder:`Masukkan NIS Santri yang akan diajukan...`,required:!0,style:{width:`100%`,maxWidth:`400px`}})]}),(0,g.jsxs)(`div`,{className:`boyong-grid`,children:[(0,g.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`8px`},children:[(0,g.jsx)(`label`,{style:{fontSize:`0.875rem`,fontWeight:600,color:`var(--text-primary)`},children:`Tahun Mondok`}),(0,g.jsx)(`input`,{type:`text`,className:`styled-input`,value:v,onChange:e=>y(e.target.value),placeholder:`Contoh: 1440/1441`,style:{width:`100%`}})]}),(0,g.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`8px`},children:[(0,g.jsx)(`label`,{style:{fontSize:`0.875rem`,fontWeight:600,color:`var(--text-primary)`},children:`Tahun Tugas Akhir`}),(0,g.jsx)(`input`,{type:`text`,className:`styled-input`,value:b,onChange:e=>x(e.target.value),placeholder:`Contoh: 1445/1446`,style:{width:`100%`}})]})]}),(0,g.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`8px`},children:[(0,g.jsx)(`label`,{style:{fontSize:`0.875rem`,fontWeight:600,color:`var(--text-primary)`},children:`Keterangan Tambahan (Opsional)`}),(0,g.jsx)(`textarea`,{className:`styled-input`,value:S,onChange:e=>C(e.target.value),placeholder:`Tambahkan catatan khusus jika diperlukan...`,rows:4,style:{width:`100%`,resize:`vertical`}})]}),(0,g.jsx)(`div`,{style:{marginTop:`8px`,paddingTop:`24px`,borderTop:`1px solid #e2e8f0`,display:`flex`,justifyContent:`flex-end`},children:(0,g.jsxs)(`button`,{type:`submit`,className:`btn btn-primary`,disabled:K.isPending,style:{display:`flex`,alignItems:`center`,gap:`10px`,padding:`12px 28px`,borderRadius:`12px`,fontSize:`0.95rem`,fontWeight:600,boxShadow:`0 4px 12px rgba(79, 70, 229, 0.25)`},children:[(0,g.jsx)(m,{size:18}),K.isPending?`Memproses Pengajuan...`:`Kirim Pengajuan Boyong`]})})]}):(0,g.jsxs)(`form`,{onSubmit:Y,style:{display:`flex`,flexDirection:`column`,gap:`32px`},children:[(0,g.jsxs)(`div`,{style:{background:`#f0f9ff`,padding:`16px 20px`,borderRadius:`12px`,border:`1px dashed #bae6fd`,color:`#0369a1`,fontSize:`0.9rem`,lineHeight:1.5},children:[(0,g.jsx)(`strong`,{children:`Data Historis:`}),` Form ini dikhususkan untuk menginput data UT-D lama (Alumni) yang belum masuk sistem. Isian disesuaikan dengan format cetak SKL agar surat kelulusan yang dihasilkan memiliki data historis yang lengkap dan akurat.`]}),(0,g.jsxs)(`div`,{children:[(0,g.jsx)(`div`,{className:`form-section-title`,children:`Data Diri Santri`}),(0,g.jsxs)(`div`,{className:`boyong-grid`,style:{marginBottom:`20px`},children:[(0,g.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`8px`},children:[(0,g.jsx)(`label`,{style:{fontSize:`0.875rem`,fontWeight:600,color:`var(--text-primary)`},children:`NIS *`}),(0,g.jsx)(`input`,{type:`text`,className:`styled-input`,value:w,onChange:e=>T(e.target.value),placeholder:`Masukkan NIS`,required:!0,style:{width:`100%`}})]}),(0,g.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`8px`},children:[(0,g.jsx)(`label`,{style:{fontSize:`0.875rem`,fontWeight:600,color:`var(--text-primary)`},children:`Nama Lengkap *`}),(0,g.jsx)(`input`,{type:`text`,className:`styled-input`,value:E,onChange:e=>D(e.target.value),placeholder:`Masukkan Nama Lengkap`,required:!0,style:{width:`100%`}})]})]}),(0,g.jsxs)(`div`,{className:`boyong-grid`,style:{marginBottom:`20px`},children:[(0,g.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`8px`},children:[(0,g.jsx)(`label`,{style:{fontSize:`0.875rem`,fontWeight:600,color:`var(--text-primary)`},children:`Tempat Lahir`}),(0,g.jsx)(`input`,{type:`text`,className:`styled-input`,value:O,onChange:e=>k(e.target.value),placeholder:`Kota Kelahiran`,style:{width:`100%`}})]}),(0,g.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`8px`},children:[(0,g.jsx)(`label`,{style:{fontSize:`0.875rem`,fontWeight:600,color:`var(--text-primary)`},children:`Tanggal Lahir`}),(0,g.jsx)(`input`,{type:`date`,className:`styled-input`,value:A,onChange:e=>j(e.target.value),style:{width:`100%`}})]})]}),(0,g.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`8px`,marginBottom:`20px`},children:[(0,g.jsx)(`label`,{style:{fontSize:`0.875rem`,fontWeight:600,color:`var(--text-primary)`},children:`Nama Wali (Ayah / Ibu)`}),(0,g.jsx)(`input`,{type:`text`,className:`styled-input`,value:M,onChange:e=>N(e.target.value),placeholder:`Nama lengkap wali`,style:{width:`100%`}})]}),(0,g.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`8px`},children:[(0,g.jsx)(`label`,{style:{fontSize:`0.875rem`,fontWeight:600,color:`var(--text-primary)`},children:`Alamat Lengkap`}),(0,g.jsx)(`textarea`,{className:`styled-input`,value:P,onChange:e=>F(e.target.value),placeholder:`Ds. Panyeppen, Kec. Palengaan, Kab. Pamekasan`,rows:3,style:{width:`100%`,resize:`vertical`}})]})]}),(0,g.jsxs)(`div`,{children:[(0,g.jsx)(`div`,{className:`form-section-title`,children:`Data Pendidikan & Penugasan`}),(0,g.jsxs)(`div`,{className:`boyong-grid`,style:{marginBottom:`24px`},children:[(0,g.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`8px`},children:[(0,g.jsx)(`label`,{style:{fontSize:`0.875rem`,fontWeight:600,color:`var(--text-primary)`},children:`Tahun Mondok`}),(0,g.jsx)(`input`,{type:`text`,className:`styled-input`,value:R,onChange:e=>z(e.target.value),placeholder:`Contoh: 1440/1441`,style:{width:`100%`}})]}),(0,g.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`8px`},children:[(0,g.jsx)(`label`,{style:{fontSize:`0.875rem`,fontWeight:600,color:`var(--text-primary)`},children:`Tahun Tugas Akhir`}),(0,g.jsx)(`input`,{type:`text`,className:`styled-input`,value:B,onChange:e=>V(e.target.value),placeholder:`Contoh: 1445/1446`,style:{width:`100%`}})]})]}),(0,g.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`16px`},children:[(0,g.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`},children:[(0,g.jsx)(`label`,{style:{fontSize:`0.95rem`,fontWeight:700,color:`var(--text-primary)`},children:`Riwayat Tempat Tugas`}),(0,g.jsxs)(`button`,{type:`button`,onClick:X,style:{display:`flex`,alignItems:`center`,gap:`6px`,background:`#f0f9ff`,border:`1px solid #bae6fd`,color:`#0284c7`,padding:`6px 14px`,borderRadius:`8px`,fontSize:`0.8rem`,fontWeight:600,cursor:`pointer`,transition:`all 0.2s`},children:[(0,g.jsx)(i,{size:16}),` Tambah Lembaga`]})]}),I.map((e,t)=>(0,g.jsxs)(`div`,{className:`pjutd-card`,children:[I.length>1&&(0,g.jsx)(`button`,{type:`button`,onClick:()=>Z(t),style:{position:`absolute`,top:`12px`,right:`12px`,background:`#fef2f2`,border:`none`,color:`#ef4444`,width:`32px`,height:`32px`,borderRadius:`8px`,display:`flex`,alignItems:`center`,justifyContent:`center`,cursor:`pointer`,transition:`all 0.2s`},title:`Hapus Lembaga`,children:(0,g.jsx)(a,{size:16})}),(0,g.jsxs)(`div`,{className:`boyong-grid`,style:{gap:`16px`,paddingRight:I.length>1?`40px`:`0`},children:[(0,g.jsxs)(`div`,{style:{flex:2,display:`flex`,flexDirection:`column`,gap:`6px`},children:[(0,g.jsx)(`label`,{style:{fontSize:`0.8rem`,fontWeight:600,color:`var(--text-secondary)`},children:`Lembaga Tugas (PJU-TD) *`}),(0,g.jsx)(p,{options:G,value:e.pjutd_id,onChange:e=>Q(t,`pjutd_id`,e),placeholder:`Ketik untuk mencari lembaga...`,required:t===0})]}),(0,g.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr 100px`,gap:`16px`},children:[(0,g.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`6px`},children:[(0,g.jsx)(`label`,{style:{fontSize:`0.8rem`,fontWeight:600,color:`var(--text-secondary)`},children:`Thn Pendidikan *`}),(0,g.jsx)(`input`,{type:`text`,className:`styled-input`,value:e.tahun_pendidikan,onChange:e=>Q(t,`tahun_pendidikan`,e.target.value),placeholder:`1445/1446`,required:t===0,style:{width:`100%`}})]}),(0,g.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`6px`},children:[(0,g.jsx)(`label`,{style:{fontSize:`0.8rem`,fontWeight:600,color:`var(--text-secondary)`},children:`Nilai *`}),(0,g.jsxs)(`select`,{className:`styled-input`,value:e.nilai,onChange:e=>Q(t,`nilai`,e.target.value),style:{width:`100%`,background:`white`},children:[(0,g.jsx)(`option`,{value:`A`,children:`A`}),(0,g.jsx)(`option`,{value:`B`,children:`B`}),(0,g.jsx)(`option`,{value:`C`,children:`C`}),(0,g.jsx)(`option`,{value:`D`,children:`D`})]})]})]})]})]},t))]})]}),(0,g.jsx)(`div`,{style:{marginTop:`8px`,paddingTop:`24px`,borderTop:`1px solid #e2e8f0`,display:`flex`,justifyContent:`flex-end`},children:(0,g.jsxs)(`button`,{type:`submit`,className:`btn btn-primary`,disabled:q.isPending,style:{background:`linear-gradient(135deg, #0ea5e9 0%, #2563eb 100%)`,display:`flex`,alignItems:`center`,gap:`10px`,padding:`12px 28px`,borderRadius:`12px`,fontSize:`0.95rem`,fontWeight:600,boxShadow:`0 4px 12px rgba(14, 165, 233, 0.25)`},children:[(0,g.jsx)(l,{size:18}),q.isPending?`Menyimpan...`:`Simpan Data Alumni (Manual)`]})})]})]})]})]})};export{_ as default};