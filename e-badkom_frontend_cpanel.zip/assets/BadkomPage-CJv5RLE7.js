import{t as e}from"./useQuery-pglRwBmA.js";import{t}from"./useMutation-CGep55OV.js";import{t as n}from"./building-2-B6DyXf6-.js";import{t as r}from"./TablePagination-C8J5xpJ1.js";import{n as i,r as a,t as o}from"./ActionDropdown-CszKUSzA.js";import{t as s}from"./file-text-BqU-vWop.js";import{t as c}from"./pen-DqundwET.js";import{t as l}from"./search-Del4_KQJ.js";import{t as u}from"./trash-2-B0D5ZvXT.js";import{t as d}from"./upload-CwExKFx3.js";import{I as f,L as p,_ as m,g as h,i as g,r as _,t as v,v as y}from"./index-BttRe-zx.js";var b=p(f(),1),x=y(),S=()=>{let{showConfirm:f}=_(),p=m(),[y,S]=(0,b.useState)(!1),[C,w]=(0,b.useState)(``),T=(0,b.useRef)(null),E=(0,b.useRef)(null),[D,O]=(0,b.useState)(1),[k,A]=(0,b.useState)(10),j={kode_badkom:``,nama_pj:``,email:``,wilayah_koordinasi:``,alamat:``,no_hp:``},[M,N]=(0,b.useState)(j),[P,F]=(0,b.useState)(``),{data:I,isLoading:L}=e({queryKey:[`badkom`],queryFn:async()=>(await v.get(`/badkom`)).data}),R=(0,b.useMemo)(()=>I?I.filter(e=>e.kode_badkom.toLowerCase().includes(C.toLowerCase())||e.nama_pj.toLowerCase().includes(C.toLowerCase())||e.wilayah_koordinasi.toLowerCase().includes(C.toLowerCase())):[],[I,C]),z=Math.ceil(R.length/k),B=R.slice((D-1)*k,D*k);b.useEffect(()=>{O(1)},[C]);let V=t({mutationFn:e=>e.id?v.put(`/badkom/${e.id}`,e):v.post(`/badkom`,e),onSuccess:()=>{p.invalidateQueries({queryKey:[`badkom`]}),S(!1),N(j),F(``)},onError:e=>{F(e.response?.data?.message||`Gagal menyimpan data`)}}),H=t({mutationFn:e=>v.delete(`/badkom/${e}`),onSuccess:()=>{p.invalidateQueries({queryKey:[`badkom`]})},onError:()=>{h.error(`Gagal menghapus data.`)}}),U=e=>{e.preventDefault(),V.mutate(M)},W=e=>{f(`Apakah Anda yakin ingin menghapus data Badkom ini?`,()=>{H.mutate(e)})},G=e=>{N(e),S(!0)};return(0,x.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`24px`,animation:`fadeIn 0.5s ease`},children:[(0,x.jsx)(`style`,{children:`
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        
        .page-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          flex-wrap: wrap;
          gap: 16px;
          background: #ffffff;
          padding: 16px 20px;
          border-radius: 16px;
          box-shadow: 0 4px 20px rgba(0,0,0,0.03);
          border: 1px solid #f1f5f9;
        }

        .search-container {
          position: relative;
          width: 320px;
        }
        
        .search-input {
          width: 100%;
          padding: 8px 16px 8px 40px;
          border-radius: 30px;
          border: 1px solid #e2e8f0;
          background: #f8fafc;
          transition: all 0.3s ease;
          font-size: 0.95rem;
        }
        
        .search-input:focus {
          background: #ffffff;
          border-color: var(--secondary);
          box-shadow: 0 0 0 4px rgba(0, 143, 215, 0.1);
          outline: none;
        }

        .action-buttons {
          display: flex;
          gap: 12px;
          flex-wrap: wrap;
        }

        .data-table-container {
          background: #ffffff;
          border-radius: 16px;
          box-shadow: 0 4px 20px rgba(0,0,0,0.03);
          border: 1px solid #f1f5f9;
          overflow-y: hidden;
          overflow-x: auto;
        }

        .data-table {
          width: 100%;
          min-width: 800px;
          border-collapse: collapse;
          text-align: left;
        }

        .data-table th {
          padding: 18px 24px;
          font-weight: 600;
          color: #64748b;
          background: #f8fafc;
          border-bottom: 1px solid #e2e8f0;
          text-transform: uppercase;
          font-size: 0.75rem;
          letter-spacing: 0.05em;
        }

        .data-table td {
          padding: 16px 24px;
          border-bottom: 1px solid #f1f5f9;
          transition: background 0.2s ease;
          vertical-align: middle;
        }

        .data-table tbody tr {
          transition: all 0.2s ease;
        }

        .data-table tbody tr:hover {
          background: #f8fafc;
          transform: scale(1.001);
        }

        .action-btn {
          border: none;
          background: none;
          cursor: pointer;
          width: 36px;
          height: 36px;
          border-radius: 50%;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }

        .action-btn.edit { color: #64748b; }
        .action-btn.edit:hover { background: #f1f5f9; color: #0f172a; }

        .action-btn.delete { color: #ef4444; }
        .action-btn.delete:hover { background: #fee2e2; }
      `}),(0,x.jsxs)(`div`,{className:`flex flex-col md:flex-row justify-between items-center gap-4 bg-white p-5 rounded-2xl shadow-[0_4px_20px_rgba(0,0,0,0.03)] border border-slate-100`,children:[(0,x.jsxs)(`div`,{className:`relative w-full md:w-80`,children:[(0,x.jsx)(`div`,{className:`absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none`,children:(0,x.jsx)(l,{size:20,className:`text-slate-400`})}),(0,x.jsx)(`input`,{type:`text`,className:`w-full pl-10 pr-4 py-2 rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-4 focus:ring-[#008FD7]/10 focus:border-[#008FD7] transition-all text-sm`,placeholder:`Cari badkom...`,value:C,onChange:e=>w(e.target.value)})]}),(0,x.jsxs)(`div`,{className:`flex flex-wrap items-center gap-2 w-full md:w-auto`,children:[(0,x.jsx)(o,{label:`Template`,icon:(0,x.jsx)(s,{size:16}),buttonStyle:{background:`#f8fafc`,color:`#475569`,border:`1px solid #e2e8f0`},items:[{label:`Template CSV`,icon:(0,x.jsx)(s,{size:14}),onClick:async()=>{try{let e=await v.get(`/badkom/template/csv`,{responseType:`blob`}),t=window.URL.createObjectURL(new Blob([e.data])),n=document.createElement(`a`);n.href=t,n.setAttribute(`download`,`badkom_template.csv`),document.body.appendChild(n),n.click(),n.remove()}catch(e){console.error(e),h.error(`Gagal mengunduh template.`)}}},{label:`Template Excel`,icon:(0,x.jsx)(i,{size:14}),onClick:async()=>{try{let e=await v.get(`/badkom/template/excel`,{responseType:`blob`}),t=window.URL.createObjectURL(new Blob([e.data])),n=document.createElement(`a`);n.href=t,n.setAttribute(`download`,`badkom_template.xlsx`),document.body.appendChild(n),n.click(),n.remove()}catch(e){console.error(e),h.error(`Gagal mengunduh template Excel.`)}}}]}),(0,x.jsx)(o,{label:`Export`,icon:(0,x.jsx)(a,{size:16}),buttonStyle:{background:`#f0f9ff`,color:`#0369a1`,border:`1px solid #bae6fd`},items:[{label:`Export CSV`,icon:(0,x.jsx)(s,{size:14}),onClick:async()=>{try{let e=await v.get(`/badkom/export/csv`,{responseType:`blob`}),t=window.URL.createObjectURL(new Blob([e.data])),n=document.createElement(`a`);n.href=t,n.setAttribute(`download`,`badkom_export.csv`),document.body.appendChild(n),n.click(),n.remove()}catch(e){console.error(e),h.error(`Gagal mengekspor data.`)}}},{label:`Export Excel`,icon:(0,x.jsx)(i,{size:14}),onClick:async()=>{try{let e=await v.get(`/badkom/export/excel`,{responseType:`blob`}),t=window.URL.createObjectURL(new Blob([e.data])),n=document.createElement(`a`);n.href=t,n.setAttribute(`download`,`badkom_export.xlsx`),document.body.appendChild(n),n.click(),n.remove()}catch(e){console.error(e),h.error(`Gagal mengekspor data Excel.`)}}}]}),(0,x.jsx)(o,{label:`Import`,icon:(0,x.jsx)(d,{size:16}),buttonStyle:{background:`#f0fdf4`,color:`#15803d`,border:`1px solid #bbf7d0`},items:[{label:`Import CSV`,icon:(0,x.jsx)(s,{size:14}),onClick:()=>T.current?.click()},{label:`Import Excel`,icon:(0,x.jsx)(i,{size:14}),onClick:()=>E.current?.click()}]}),(0,x.jsx)(`input`,{type:`file`,ref:T,className:`hidden`,accept:`.csv`,onChange:async e=>{let t=e.target.files?.[0];if(!t)return;let n=new FormData;n.append(`file`,t);try{let e=await v.post(`/badkom/import/csv`,n,{headers:{"Content-Type":`multipart/form-data`}});h.success(e.data.message),p.invalidateQueries({queryKey:[`badkom`]})}catch(e){h.error(e.response?.data?.message||`Gagal mengimpor file.`)}T.current&&(T.current.value=``)}}),(0,x.jsx)(`input`,{type:`file`,ref:E,className:`hidden`,accept:`.xlsx,.xls`,onChange:async e=>{let t=e.target.files?.[0];if(!t)return;let n=new FormData;n.append(`file`,t);try{let e=await v.post(`/badkom/import/excel`,n,{headers:{"Content-Type":`multipart/form-data`}});h.success(e.data.message),p.invalidateQueries({queryKey:[`badkom`]})}catch(e){h.error(e.response?.data?.message||`Gagal mengimpor file Excel.`)}E.current&&(E.current.value=``)}}),(0,x.jsxs)(`button`,{className:`flex items-center gap-2 bg-[#422F6F] hover:bg-[#1e293b] text-white px-4 py-2 rounded-lg text-sm font-medium transition-all shadow-sm hover:shadow w-full md:w-auto justify-center`,onClick:()=>{N(j),S(!0)},children:[(0,x.jsx)(n,{size:16}),`Tambah Badkom`]})]})]}),(0,x.jsxs)(`div`,{className:`data-table-container`,children:[(0,x.jsxs)(`table`,{className:`data-table`,children:[(0,x.jsx)(`thead`,{children:(0,x.jsxs)(`tr`,{children:[(0,x.jsx)(`th`,{children:`Kode`}),(0,x.jsx)(`th`,{children:`Wilayah Koordinasi`}),(0,x.jsx)(`th`,{children:`Nama PJ`}),(0,x.jsx)(`th`,{className:`text-right`,children:`Aksi`})]})}),(0,x.jsx)(`tbody`,{children:L?(0,x.jsx)(`tr`,{children:(0,x.jsx)(`td`,{colSpan:5,style:{padding:`40px`,textAlign:`center`,color:`var(--text-secondary)`},children:`Memuat data...`})}):B?.length===0?(0,x.jsx)(`tr`,{children:(0,x.jsx)(`td`,{colSpan:5,style:{padding:`40px`,textAlign:`center`,color:`var(--text-secondary)`},children:`Tidak ada data badkom.`})}):B?.map(e=>(0,x.jsxs)(`tr`,{children:[(0,x.jsx)(`td`,{style:{fontWeight:600,color:`#334155`},children:(0,x.jsx)(`span`,{style:{padding:`4px 12px`,background:`#e0f2fe`,color:`#0369a1`,borderRadius:`20px`,fontSize:`0.75rem`},children:e.kode_badkom})}),(0,x.jsx)(`td`,{style:{fontWeight:500,color:`#0f172a`},children:e.wilayah_koordinasi}),(0,x.jsx)(`td`,{style:{color:`#475569`},children:e.nama_pj}),(0,x.jsx)(`td`,{className:`text-right`,children:(0,x.jsxs)(`div`,{style:{display:`flex`,justifyContent:`flex-end`,gap:`4px`},children:[(0,x.jsx)(`button`,{className:`action-btn edit`,onClick:()=>G(e),title:`Edit Badkom`,children:(0,x.jsx)(c,{size:18})}),(0,x.jsx)(`button`,{className:`action-btn delete`,onClick:()=>W(e.id),title:`Hapus Badkom`,children:(0,x.jsx)(u,{size:18})})]})})]},e.id))})]}),!L&&(0,x.jsx)(r,{currentPage:D,totalPages:z,totalItems:R.length,itemsPerPage:k,onPageChange:O,onItemsPerPageChange:e=>{A(e),O(1)}})]}),(0,x.jsx)(g,{isOpen:y,onClose:()=>S(!1),title:M.id?`Edit Data Badkom`:`Tambah Data Badkom`,maxWidth:`600px`,children:(0,x.jsxs)(`form`,{onSubmit:U,className:`flex flex-col gap-6`,children:[P&&(0,x.jsx)(`div`,{style:{background:`#fef2f2`,color:`#b91c1c`,padding:`12px`,borderRadius:`8px`,fontSize:`0.875rem`},children:P}),(0,x.jsxs)(`div`,{style:{background:`#f8fafc`,padding:`20px`,borderRadius:`12px`,border:`1px solid #e2e8f0`},children:[(0,x.jsx)(`h3`,{style:{fontSize:`0.875rem`,fontWeight:700,color:`#475569`,textTransform:`uppercase`,letterSpacing:`0.05em`,marginBottom:`16px`},children:`Identitas Badkom`}),(0,x.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr 2fr`,gap:`16px`},children:[(0,x.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`6px`},children:[(0,x.jsx)(`label`,{className:`form-label`,children:`KODE BADKOM *`}),(0,x.jsx)(`input`,{type:`text`,placeholder:`Misal: BDK-01`,value:M.kode_badkom||``,onChange:e=>N({...M,kode_badkom:e.target.value}),required:!0})]}),(0,x.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`6px`},children:[(0,x.jsx)(`label`,{className:`form-label`,children:`CAKUPAN WILAYAH KOORDINASI *`}),(0,x.jsx)(`input`,{type:`text`,placeholder:`Misal: Kecamatan A dan B`,value:M.wilayah_koordinasi||``,onChange:e=>N({...M,wilayah_koordinasi:e.target.value}),required:!0})]})]})]}),(0,x.jsxs)(`div`,{style:{background:`#f8fafc`,padding:`20px`,borderRadius:`12px`,border:`1px solid #e2e8f0`},children:[(0,x.jsx)(`h3`,{style:{fontSize:`0.875rem`,fontWeight:700,color:`#475569`,textTransform:`uppercase`,letterSpacing:`0.05em`,marginBottom:`16px`},children:`Data Penanggung Jawab (PJ)`}),(0,x.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`16px`},children:[(0,x.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`6px`},children:[(0,x.jsx)(`label`,{className:`form-label`,children:`NAMA LENGKAP PJ *`}),(0,x.jsx)(`input`,{type:`text`,placeholder:`Nama Lengkap Penanggung Jawab`,value:M.nama_pj||``,onChange:e=>N({...M,nama_pj:e.target.value}),required:!0})]}),(0,x.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:`16px`},children:[(0,x.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`6px`},children:[(0,x.jsx)(`label`,{className:`form-label`,children:`ALAMAT EMAIL`}),(0,x.jsx)(`input`,{type:`email`,placeholder:`email@contoh.com`,value:M.email||``,onChange:e=>N({...M,email:e.target.value})})]}),(0,x.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`6px`},children:[(0,x.jsx)(`label`,{className:`form-label`,children:`NOMOR HP / WHATSAPP`}),(0,x.jsx)(`input`,{type:`text`,placeholder:`Mulai dengan 62xxx`,value:M.no_hp||``,onChange:e=>N({...M,no_hp:e.target.value})})]})]})]})]}),(0,x.jsxs)(`div`,{style:{background:`#f8fafc`,padding:`20px`,borderRadius:`12px`,border:`1px solid #e2e8f0`},children:[(0,x.jsx)(`h3`,{style:{fontSize:`0.875rem`,fontWeight:700,color:`#475569`,textTransform:`uppercase`,letterSpacing:`0.05em`,marginBottom:`16px`},children:`Alamat`}),(0,x.jsx)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`16px`},children:(0,x.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`6px`},children:[(0,x.jsx)(`label`,{className:`form-label`,children:`ALAMAT KANTOR / BADKOM`}),(0,x.jsx)(`textarea`,{placeholder:`Detail Alamat (Jalan, RT/RW, Desa)`,value:M.alamat||``,onChange:e=>N({...M,alamat:e.target.value}),rows:2})]})})]}),(0,x.jsxs)(`div`,{style:{marginTop:`8px`,display:`flex`,gap:`12px`,justifyContent:`flex-end`,paddingTop:`16px`,borderTop:`1px solid #e2e8f0`},children:[(0,x.jsx)(`button`,{type:`button`,className:`btn`,onClick:()=>S(!1),style:{background:`white`,color:`#64748b`,border:`1px solid #e2e8f0`},children:`Batal`}),(0,x.jsx)(`button`,{type:`submit`,className:`btn btn-primary`,disabled:V.isPending,children:V.isPending?`Menyimpan...`:`Simpan Data`})]})]})})]})};export{S as default};