import{t as e}from"./useQuery-CXuh9pCg.js";import{t}from"./useMutation-CaaXOH63.js";import{t as n}from"./TablePagination-BNBjUTjL.js";import{t as r}from"./circle-alert-Dmx7fYh9.js";import{t as i}from"./plus-Cae9_s9q.js";import{t as a}from"./refresh-ccw-B9mRj-cs.js";import{t as o}from"./search-DIzmh7Yz.js";import{I as s,L as c,_ as l,g as u,i as d,t as f,v as p}from"./index-BlbFHRWW.js";import{t as m}from"./SearchableSelect-BSN_gOck.js";var h=c(s(),1),g=p(),_=()=>{let s=l(),[c,p]=(0,h.useState)(!1),[_,v]=(0,h.useState)(1),[y,b]=(0,h.useState)(10),[x,S]=(0,h.useState)(``),[C,w]=(0,h.useState)({utd_id:``,tujuan_pjutd_id:``,alasan:``,tanggal_mutasi:new Date().toISOString().split(`T`)[0]}),T=localStorage.getItem(`user`),E=T?JSON.parse(T):null,D=E?.level===`badkom_wilayah`,{data:O=[]}=e({queryKey:[`tahun_ajaran`],queryFn:async()=>(await f.get(`/tahun-ajaran`)).data}),k=O.find(e=>e.is_active),{data:A=[],isLoading:j}=e({queryKey:[`mutasi`],queryFn:async()=>(await f.get(`/mutasi`)).data}),{data:M=[]}=e({queryKey:[`utd`,k?.id],queryFn:async()=>(await f.get(`/utd?tahun_ajaran_id=${k?.id}`)).data,enabled:!!k&&c}),{data:N=[]}=e({queryKey:[`pjutd`],queryFn:async()=>(await f.get(`/pjutd`)).data,enabled:c}),P=t({mutationFn:e=>f.post(`/mutasi`,e),onSuccess:()=>{s.invalidateQueries({queryKey:[`mutasi`]}),s.invalidateQueries({queryKey:[`utd`]}),p(!1),w({utd_id:``,tujuan_pjutd_id:``,alasan:``,tanggal_mutasi:new Date().toISOString().split(`T`)[0]}),u.success(`Mutasi berhasil diproses`)},onError:e=>{u.error(e.response?.data?.message||`Terjadi kesalahan saat memproses mutasi`)}}),F=e=>{e.preventDefault(),P.mutate(C)},I=A.filter(e=>e.utd?.santri?.nama?.toLowerCase().includes(x.toLowerCase())||e.alasan.toLowerCase().includes(x.toLowerCase())),L=Math.ceil(I.length/y),R=I.slice((_-1)*y,_*y);N.filter(e=>D?e.badkom_id===E.badkom_id:!0);let z=M.filter(e=>D?e.pjutd?.badkom_id===E.badkom_id:!0),B=M.find(e=>e.id===Number(C.utd_id));return(0,g.jsxs)(g.Fragment,{children:[(0,g.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`24px`,animation:`fadeIn 0.5s ease`},children:[(0,g.jsx)(`style`,{children:`
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        
        .page-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          flex-wrap: wrap;
          gap: 16px;
          background: #ffffff;
          padding: 16px 20px;
          border-radius: 16px;
          box-shadow: 0 4px 20px rgba(0,0,0,0.03);
          border: 1px solid #f1f5f9;
        }

        .search-container {
          position: relative;
          width: 320px;
        }
        
        .search-input {
          width: 100%;
          padding: 8px 16px 8px 40px;
          border-radius: 30px;
          border: 1px solid #e2e8f0;
          background: #f8fafc;
          transition: all 0.3s ease;
          font-size: 0.95rem;
        }
        
        .search-input:focus {
          background: #ffffff;
          border-color: var(--secondary);
          box-shadow: 0 0 0 4px rgba(0, 143, 215, 0.1);
          outline: none;
        }

        .action-buttons {
          display: flex;
          gap: 12px;
          flex-wrap: nowrap;
          align-items: center;
        }

        .data-table-container {
          background: #ffffff;
          border-radius: 16px;
          box-shadow: 0 4px 20px rgba(0,0,0,0.03);
          border: 1px solid #f1f5f9;
          overflow-y: hidden;
          overflow-x: auto;
        }

        .data-table {
          width: 100%;
          min-width: 800px;
          border-collapse: collapse;
          text-align: left;
        }

        .data-table th {
          padding: 18px 24px;
          font-weight: 600;
          color: #64748b;
          background: #f8fafc;
          border-bottom: 1px solid #e2e8f0;
          text-transform: uppercase;
          font-size: 0.75rem;
          letter-spacing: 0.05em;
        }

        .data-table td {
          padding: 16px 24px;
          border-bottom: 1px solid #f1f5f9;
          transition: background 0.2s ease;
          vertical-align: middle;
        }

        .data-table tbody tr {
          transition: all 0.2s ease;
        }

        .data-table tbody tr:hover {
          background: #f8fafc;
          transform: scale(1.001);
        }
      `}),(0,g.jsxs)(`div`,{className:`flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 bg-white p-5 rounded-2xl shadow-[0_4px_20px_rgba(0,0,0,0.03)] border border-slate-100`,children:[(0,g.jsxs)(`div`,{className:`flex items-center gap-4 w-full lg:w-auto`,children:[(0,g.jsx)(`div`,{className:`p-2 bg-sky-50 text-sky-600 rounded-xl`,children:(0,g.jsx)(a,{size:24})}),(0,g.jsxs)(`div`,{children:[(0,g.jsx)(`h2`,{className:`m-0 text-xl text-slate-900 font-bold`,children:`Riwayat Mutasi Tugas`}),(0,g.jsx)(`p`,{className:`m-0 mt-1 text-sm text-slate-500`,children:`Daftar kepindahan tugas ustadz/ustadzah daerah`})]})]}),(0,g.jsxs)(`div`,{className:`flex flex-wrap items-center gap-3 w-full lg:w-auto`,children:[(0,g.jsxs)(`div`,{className:`relative w-full md:w-64`,children:[(0,g.jsx)(`div`,{className:`absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none`,children:(0,g.jsx)(o,{size:16,className:`text-slate-400`})}),(0,g.jsx)(`input`,{type:`text`,placeholder:`Cari nama atau alasan...`,className:`w-full pl-10 pr-4 py-2 rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-4 focus:ring-[#008FD7]/10 focus:border-[#008FD7] transition-all text-sm`,value:x,onChange:e=>S(e.target.value)})]}),(0,g.jsxs)(`button`,{className:`flex items-center gap-2 bg-[#422F6F] hover:bg-[#1e293b] text-white px-4 py-2 rounded-lg text-sm font-medium transition-all shadow-sm hover:shadow w-full md:w-auto justify-center`,onClick:()=>p(!0),children:[(0,g.jsx)(i,{size:16}),` Ajukan Mutasi`]})]})]}),j?(0,g.jsx)(`div`,{style:{padding:`40px`,textAlign:`center`,color:`#64748b`},children:`Memuat data...`}):(0,g.jsxs)(`div`,{className:`data-table-container`,children:[(0,g.jsxs)(`table`,{className:`data-table`,children:[(0,g.jsx)(`thead`,{children:(0,g.jsxs)(`tr`,{children:[(0,g.jsx)(`th`,{children:`Tanggal`}),(0,g.jsx)(`th`,{children:`Ustadz Tugas`}),(0,g.jsx)(`th`,{children:`Lembaga Asal`}),(0,g.jsx)(`th`,{children:`Lembaga Tujuan`}),(0,g.jsx)(`th`,{children:`Alasan`}),(0,g.jsx)(`th`,{children:`Diproses Oleh`})]})}),(0,g.jsxs)(`tbody`,{children:[R.map(e=>(0,g.jsxs)(`tr`,{children:[(0,g.jsx)(`td`,{style:{fontWeight:600,color:`#334155`},children:new Date(e.tanggal_mutasi).toLocaleDateString(`id-ID`)}),(0,g.jsxs)(`td`,{children:[(0,g.jsx)(`div`,{style:{fontWeight:600,color:`#0f172a`},children:e.utd?.santri?.nama}),(0,g.jsxs)(`div`,{style:{fontSize:`0.85rem`,color:`#64748b`},children:[`NIS: `,e.utd?.santri?.nis]})]}),(0,g.jsx)(`td`,{children:(0,g.jsx)(`span`,{style:{fontWeight:600,color:`#b91c1c`,background:`#fef2f2`,padding:`4px 12px`,borderRadius:`12px`,fontSize:`0.85rem`},children:e.asal_pjutd?.nama_madrasah||e.asal_pjutd?.yayasan||e.asal_pjutd?.nama_pjutd})}),(0,g.jsx)(`td`,{children:(0,g.jsx)(`span`,{style:{fontWeight:600,color:`#047857`,background:`#d1fae5`,padding:`4px 12px`,borderRadius:`12px`,fontSize:`0.85rem`},children:e.tujuan_pjutd?.nama_madrasah||e.tujuan_pjutd?.yayasan||e.tujuan_pjutd?.nama_pjutd})}),(0,g.jsx)(`td`,{style:{maxWidth:`200px`},children:(0,g.jsx)(`div`,{style:{fontSize:`0.85rem`,color:`#475569`,display:`-webkit-box`,WebkitLineClamp:2,WebkitBoxOrient:`vertical`,overflow:`hidden`},title:e.alasan,children:e.alasan})}),(0,g.jsx)(`td`,{style:{fontSize:`0.85rem`,color:`#64748b`,fontWeight:500},children:e.user?.fullname||e.user?.username})]},e.id)),R.length===0&&(0,g.jsx)(`tr`,{children:(0,g.jsx)(`td`,{colSpan:6,style:{padding:`32px`,textAlign:`center`,color:`#94a3b8`},children:`Belum ada riwayat mutasi`})})]})]}),I.length>0&&(0,g.jsx)(`div`,{style:{padding:`0 24px 24px 24px`},children:(0,g.jsx)(n,{currentPage:_,totalPages:L,totalItems:I.length,itemsPerPage:y,onPageChange:v,onItemsPerPageChange:e=>{b(e),v(1)}})})]})]}),(0,g.jsx)(d,{isOpen:c,onClose:()=>p(!1),title:`Formulir Mutasi Ustadz Tugas`,children:k?(0,g.jsxs)(`form`,{onSubmit:F,style:{display:`flex`,flexDirection:`column`,gap:`16px`},children:[(0,g.jsxs)(`div`,{style:{background:`#f8fafc`,padding:`24px`,borderRadius:`16px`,border:`1px solid #e2e8f0`,display:`flex`,flexDirection:`column`,gap:`16px`},children:[(0,g.jsxs)(`div`,{className:`form-group`,style:{marginBottom:0},children:[(0,g.jsx)(`label`,{className:`form-label`,children:`Pilih Ustadz Tugas (Yang Sedang Bertugas)`}),(0,g.jsx)(m,{options:z.map(e=>({value:e.id,label:`${e.santri?.nama} - (Saat ini: ${e.pjutd?.nama_madrasah||e.pjutd?.yayasan||e.pjutd?.nama_pjutd})`})),value:C.utd_id?Number(C.utd_id):void 0,onChange:e=>w({...C,utd_id:e.toString()}),placeholder:`-- Cari dan Pilih Ustadz --`,required:!0})]}),(0,g.jsxs)(`div`,{className:`form-group`,style:{marginBottom:0},children:[(0,g.jsx)(`label`,{className:`form-label`,children:`Lembaga Tujuan Mutasi`}),(0,g.jsx)(m,{options:N.filter(e=>e.id!==B?.pjutd_id).map(e=>({value:e.id,label:`${e.kode_lembaga} - ${e.nama_madrasah||e.yayasan||e.nama_pjutd}`})),value:C.tujuan_pjutd_id?Number(C.tujuan_pjutd_id):void 0,onChange:e=>w({...C,tujuan_pjutd_id:e.toString()}),placeholder:`-- Cari dan Pilih Tujuan --`,required:!0,disabled:!C.utd_id})]}),(0,g.jsxs)(`div`,{className:`form-group`,style:{marginBottom:0},children:[(0,g.jsx)(`label`,{className:`form-label`,children:`Tanggal Mutasi`}),(0,g.jsx)(`input`,{type:`date`,className:`form-control`,required:!0,value:C.tanggal_mutasi,onChange:e=>w({...C,tanggal_mutasi:e.target.value})})]}),(0,g.jsxs)(`div`,{className:`form-group`,style:{marginBottom:0},children:[(0,g.jsx)(`label`,{className:`form-label`,children:`Alasan Mutasi`}),(0,g.jsx)(`textarea`,{className:`form-control`,rows:3,required:!0,placeholder:`Jelaskan alasan pemindahan tugas secara detail...`,value:C.alasan,onChange:e=>w({...C,alasan:e.target.value})})]})]}),(0,g.jsxs)(`div`,{style:{display:`flex`,justifyContent:`flex-end`,gap:`12px`,marginTop:`16px`},children:[(0,g.jsx)(`button`,{type:`button`,className:`btn`,onClick:()=>p(!1),children:`Batal`}),(0,g.jsx)(`button`,{type:`submit`,className:`btn btn-primary`,disabled:P.isPending,children:P.isPending?`Memproses...`:`Proses Mutasi`})]})]}):(0,g.jsxs)(`div`,{style:{padding:`16px`,background:`#fee2e2`,color:`#b91c1c`,borderRadius:`8px`,display:`flex`,alignItems:`center`,gap:`8px`},children:[(0,g.jsx)(r,{size:20}),`Tidak ada Tahun Ajaran aktif. Tidak bisa melakukan mutasi.`]})})]})};export{_ as default};