import{t as e}from"./useQuery-CXuh9pCg.js";import{t}from"./useMutation-CaaXOH63.js";import{t as n}from"./circle-alert-Dmx7fYh9.js";import{t as r}from"./circle-check-big-gWvC_Byt.js";import{t as i}from"./clock-CRxFXP8Z.js";import{n as a,r as o,t as s}from"./CetakLaporanWajibPjutd-p69Sz6xr.js";import{t as c}from"./file-text-GPUAS2Aa.js";import{t as l}from"./plus-Cae9_s9q.js";import{t as u}from"./printer-BUGR1xU1.js";import{I as d,L as f,_ as ee,i as p,t as m,v as h}from"./index-BlbFHRWW.js";var g=f(d(),1),_=h(),te=({laporan:e,kopSuratUrl:t})=>{if(!e)return null;let n=e.user,r=n?.level,i=n?.santri?.nama_lengkap||`-`,a=n?.pjutd?.nama_pjutd||n?.fullname||`-`,o=n?.pjutd?.nama_madrasah||n?.pjutd?.yayasan||`-`,s=n?.pjutd?.alamat||`-`,c=n?.pjutd?.badkom?.nama_badkom||n?.badkom_wilayah?.nama_badkom||`-`,l=n?.fullname||`.........................`,u=r===`utd`?`Ustadz Tugas & Da'i`:r===`pjutd`?`Penanggung Jawab UT-D`:`Pengirim`;return(0,_.jsxs)(`div`,{className:`print-only`,style:{padding:`20px 40px`,fontFamily:`"Times New Roman", Times, serif`,color:`black`,fontSize:`11pt`,lineHeight:1.3},children:[t?(0,_.jsx)(`div`,{style:{textAlign:`center`,marginBottom:`20px`,borderBottom:`3px double black`,paddingBottom:`10px`},children:(0,_.jsx)(`img`,{src:t,alt:`Kop Surat`,style:{maxWidth:`100%`,maxHeight:`180px`,objectFit:`contain`}})}):(0,_.jsx)(`div`,{style:{position:`relative`,marginBottom:`20px`,borderBottom:`3px double black`,paddingBottom:`10px`},children:(0,_.jsxs)(`div`,{style:{marginLeft:`90px`,textAlign:`left`},children:[(0,_.jsx)(`h1`,{style:{display:`inline`,fontSize:`20pt`,margin:0,color:`#000080`,letterSpacing:`2px`},children:`BADKOM`}),(0,_.jsx)(`p`,{style:{margin:0,fontSize:`9pt`,color:`#000080`},children:`Badan Komunikasi Pendidikan dan Dakwah`}),(0,_.jsx)(`p`,{style:{margin:0,fontSize:`9pt`,color:`#000080`},children:(0,_.jsx)(`strong`,{children:`YAYASAN AL-MIFTAH PP. Miftahul Ulum Panyeppen`})}),(0,_.jsxs)(`div`,{style:{textAlign:`right`,marginTop:`-45px`,fontStyle:`italic`,fontSize:`9pt`},children:[`Ustadz Tugas & Da'i Zakat`,(0,_.jsx)(`br`,{}),`Penanggung Jawab Ustadz Tugas & Da'i`,(0,_.jsx)(`br`,{}),`Madrasah Ranting`,(0,_.jsx)(`br`,{}),`Pendidikan & Dakwah`]})]})}),(0,_.jsx)(`div`,{style:{textAlign:`center`,fontWeight:`bold`,fontSize:`14pt`,marginTop:`30px`,marginBottom:`30px`},children:`SURAT LAPORAN INSIDENTAL`}),(0,_.jsxs)(`div`,{style:{textAlign:`justify`},children:[(0,_.jsx)(`p`,{style:{marginBottom:0},children:`Kepada Yth.`}),(0,_.jsx)(`p`,{style:{fontWeight:`bold`,margin:`0`},children:`Badan Komunikasi Yayasan Al-Miftah`}),(0,_.jsx)(`p`,{style:{fontWeight:`bold`,margin:`0`},children:`PP. Miftahul Ulum Panyeppen`}),(0,_.jsx)(`p`,{style:{marginTop:0},children:`di Tempat`}),(0,_.jsx)(`p`,{style:{textAlign:`center`,fontStyle:`italic`,margin:`15px 0`},children:`Assalamu'alaikum Wr. Wb.`}),(0,_.jsx)(`p`,{style:{textIndent:`40px`},children:`Dengan hormat, bersama ini kami menyampaikan laporan kejadian yang terjadi di lembaga sebagai berikut:`}),(0,_.jsx)(`table`,{style:{width:`100%`,marginBottom:`15px`,borderCollapse:`collapse`},children:(0,_.jsxs)(`tbody`,{children:[r===`utd`?(0,_.jsxs)(_.Fragment,{children:[(0,_.jsxs)(`tr`,{children:[(0,_.jsx)(`td`,{style:{width:`150px`,padding:`3px 0`,verticalAlign:`top`},children:`Nama UT-D (Santri)`}),(0,_.jsx)(`td`,{style:{width:`10px`,padding:`3px 0`,verticalAlign:`top`},children:`:`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`},children:i})]}),(0,_.jsxs)(`tr`,{children:[(0,_.jsx)(`td`,{style:{padding:`3px 0`,verticalAlign:`top`},children:`Nama PJ UT-D`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`,verticalAlign:`top`},children:`:`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`},children:a})]}),(0,_.jsxs)(`tr`,{children:[(0,_.jsx)(`td`,{style:{padding:`3px 0`,verticalAlign:`top`},children:`Nama Lembaga`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`,verticalAlign:`top`},children:`:`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`},children:o})]}),(0,_.jsxs)(`tr`,{children:[(0,_.jsx)(`td`,{style:{padding:`3px 0`,verticalAlign:`top`},children:`Badkom Wilayah`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`,verticalAlign:`top`},children:`:`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`},children:c})]})]}):r===`pjutd`?(0,_.jsxs)(_.Fragment,{children:[(0,_.jsxs)(`tr`,{children:[(0,_.jsx)(`td`,{style:{width:`150px`,padding:`3px 0`,verticalAlign:`top`},children:`Nama PJ UT-D`}),(0,_.jsx)(`td`,{style:{width:`10px`,padding:`3px 0`,verticalAlign:`top`},children:`:`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`},children:a})]}),(0,_.jsxs)(`tr`,{children:[(0,_.jsx)(`td`,{style:{padding:`3px 0`,verticalAlign:`top`},children:`Nama Lembaga`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`,verticalAlign:`top`},children:`:`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`},children:o})]}),(0,_.jsxs)(`tr`,{children:[(0,_.jsx)(`td`,{style:{padding:`3px 0`,verticalAlign:`top`},children:`Alamat Lembaga`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`,verticalAlign:`top`},children:`:`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`},children:s})]}),(0,_.jsxs)(`tr`,{children:[(0,_.jsx)(`td`,{style:{padding:`3px 0`,verticalAlign:`top`},children:`Badkom Wilayah`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`,verticalAlign:`top`},children:`:`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`},children:c})]})]}):r===`badkom_wilayah`?(0,_.jsxs)(_.Fragment,{children:[(0,_.jsxs)(`tr`,{children:[(0,_.jsx)(`td`,{style:{width:`150px`,padding:`3px 0`,verticalAlign:`top`},children:`Nama Koordinator`}),(0,_.jsx)(`td`,{style:{width:`10px`,padding:`3px 0`,verticalAlign:`top`},children:`:`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`},children:l})]}),(0,_.jsxs)(`tr`,{children:[(0,_.jsx)(`td`,{style:{padding:`3px 0`,verticalAlign:`top`},children:`Badkom Wilayah`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`,verticalAlign:`top`},children:`:`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`},children:c})]}),(0,_.jsxs)(`tr`,{children:[(0,_.jsx)(`td`,{style:{padding:`3px 0`,verticalAlign:`top`},children:`Wilayah Koordinasi`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`,verticalAlign:`top`},children:`:`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`},children:o})]})]}):(0,_.jsxs)(`tr`,{children:[(0,_.jsx)(`td`,{style:{width:`150px`,padding:`3px 0`,verticalAlign:`top`},children:`Nama / Pengirim`}),(0,_.jsx)(`td`,{style:{width:`10px`,padding:`3px 0`,verticalAlign:`top`},children:`:`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`},children:l})]}),(0,_.jsxs)(`tr`,{children:[(0,_.jsx)(`td`,{style:{padding:`3px 0`,verticalAlign:`top`},children:`Judul Laporan`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`,verticalAlign:`top`},children:`:`}),(0,_.jsx)(`td`,{style:{padding:`3px 0`,fontWeight:`bold`},children:e.judul})]})]})}),(0,_.jsx)(`p`,{children:`Isi Laporan:`}),(0,_.jsx)(`div`,{style:{marginBottom:`10px`,whiteSpace:`pre-wrap`,lineHeight:1.5},children:e.isi_laporan}),(0,_.jsx)(`p`,{style:{textIndent:`40px`,marginTop:`15px`},children:`Demikian laporan ini kami sampaikan untuk menjadi perhatian dan tindak lanjut sebagaimana mestinya. Atas perhatian dan kerja samanya kami sampaikan terima kasih.`}),(0,_.jsx)(`p`,{style:{marginBottom:0,marginTop:`15px`},children:`Wassalamu'alaikum Wr. Wb.`}),(0,_.jsxs)(`div`,{style:{width:`100%`,marginTop:`40px`},children:[(0,_.jsxs)(`div`,{style:{float:`right`,textAlign:`center`,width:`300px`},children:[n?.pjutd?.kabupaten||`.....................................`,`, `,new Date(e.created_at).toLocaleDateString(`id-ID`,{day:`numeric`,month:`long`,year:`numeric`}),(0,_.jsx)(`br`,{}),(0,_.jsx)(`br`,{}),`Hormat kami,`,(0,_.jsx)(`br`,{}),u,(0,_.jsx)(`br`,{}),(0,_.jsx)(`br`,{}),(0,_.jsx)(`br`,{}),(0,_.jsx)(`br`,{}),(0,_.jsx)(`br`,{}),`( `,l,` )`]}),(0,_.jsx)(`div`,{style:{clear:`both`}})]})]})]})},v=()=>{let d=ee(),[f,h]=(0,g.useState)(`wajib`),[v,y]=(0,g.useState)(!1),[b,x]=(0,g.useState)(!1),[S,C]=(0,g.useState)({judul:``,isi_laporan:``}),[w,T]=(0,g.useState)({}),ne=new Date().toISOString().slice(0,7),[E,D]=(0,g.useState)(`Bulan Ke-1`),[O,k]=(0,g.useState)(``),[A,j]=(0,g.useState)(null),[M,N]=(0,g.useState)(null),{data:P=[]}=e({queryKey:[`settings`],queryFn:async()=>(await m.get(`/settings`)).data}),re=P.find(e=>e.key===`max_bulan_laporan`)?.value||12,ie=Array.from({length:parseInt(re)},(e,t)=>`Bulan Ke-${t+1}`);(0,g.useEffect)(()=>{(A||M)&&setTimeout(()=>window.print(),500)},[A,M]),(0,g.useEffect)(()=>{let e=()=>{j(null),N(null)};return window.addEventListener(`afterprint`,e),()=>window.removeEventListener(`afterprint`,e)},[]);let F=localStorage.getItem(`user`),I=F?JSON.parse(F):null,L=I?.level,R=L===`utd`||L===`pjutd`||L===`badkom_wilayah`,{data:z=[]}=e({queryKey:[`tahun_ajaran`],queryFn:async()=>(await m.get(`/tahun-ajaran`)).data});(0,g.useEffect)(()=>{if(z.length>0&&O===``){let e=z.find(e=>e.is_active);k(e?e.id:z[0].id)}},[z,O]);let{data:B=[],isLoading:ae}=e({queryKey:[`my_soal_laporan`],queryFn:async()=>(await m.get(`/laporan-wajib/soal`)).data,enabled:R}),{data:V=[],isLoading:oe}=e({queryKey:[`laporan_wajib`],queryFn:async()=>(await m.get(`/laporan-wajib`)).data}),{data:H=[],isLoading:U}=e({queryKey:[`laporan_mendesak`],queryFn:async()=>(await m.get(`/laporan-mendesak`)).data}),{data:W=[]}=e({queryKey:[`jadwal-laporan`,O],queryFn:async()=>O?(await m.get(`/jadwal-laporan-wajib`,{params:{tahun_ajaran_id:O}})).data:[],enabled:!!O}),G=W.find(e=>e.kategori_bulan===E),K=G?new Date>new Date(G.batas_tanggal):!1,q=t({mutationFn:e=>m.post(`/laporan-wajib/submit`,e),onSuccess:()=>{d.invalidateQueries({queryKey:[`laporan_wajib`]}),y(!1)}}),J=t({mutationFn:e=>m.post(`/laporan-mendesak`,e),onSuccess:()=>{d.invalidateQueries({queryKey:[`laporan_mendesak`]}),x(!1)}}),se=e=>{e.preventDefault();let t={};Object.keys(w).forEach(e=>{let n=w[e];typeof n==`object`&&n?t[e]=Object.entries(n).map(([e,t])=>`${e}: ${t}`).join(` | `):t[e]=n}),q.mutate({bulan_tahun:ne,kategori_bulan:E,jawaban:t})},ce=e=>{e.preventDefault(),J.mutate(S)},Y=z.find(e=>e.is_active),X=V.some(e=>e.user?.id===I?.id&&e.kategori_bulan===E&&e.tahun_ajaran_id===Y?.id),Z=V.filter(e=>e.user?.id===I?.id&&e.tahun_ajaran_id===O),Q=H.filter(e=>e.user?.id===I?.id&&e.tahun_ajaran_id===O),$=e=>{let t=e===`utd`?`kop_laporan_utd`:`kop_laporan_pjutd`,n=P.find(e=>e.key===t)?.value;if(n)return`https:/.e-badkom.pannyeppen.com/api/`+n};return(0,_.jsxs)(_.Fragment,{children:[(0,_.jsxs)(`div`,{className:`fade-in`,style:{display:`flex`,flexDirection:`column`,gap:`24px`,maxWidth:`1000px`,margin:`0 auto`},children:[(0,_.jsx)(`style`,{children:`
        .laporan-tab-btn {
          padding: 12px 24px;
          border-radius: 14px;
          border: none;
          display: flex;
          align-items: center;
          gap: 10px;
          font-weight: 600;
          font-size: 0.9rem;
          cursor: pointer;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          background: transparent;
          color: #64748b;
        }
        .laporan-tab-btn:hover:not(.active) {
          background: rgba(226, 232, 240, 0.5);
          color: #334155;
        }
        .laporan-tab-btn.active.wajib {
          background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
          color: white;
          box-shadow: 0 4px 15px rgba(79, 70, 229, 0.3);
        }
        @media (max-width: 768px) {
          .laporan-filter-container {
            flex-direction: column !important;
            align-items: stretch !important;
          }
          .laporan-filter-item {
            width: 100%;
            display: flex;
            justify-content: space-between;
          }
          .laporan-filter-item span {
            min-width: 60px;
          }
          .laporan-filter-divider {
            width: 100% !important;
            height: 1px !important;
            margin: 8px 0 !important;
          }
          .laporan-action-group {
            width: 100%;
            flex-direction: column !important;
            align-items: stretch !important;
            margin-left: 0 !important;
          }
          .laporan-action-group .status-badge {
            justify-content: center;
          }
          .laporan-action-group button, .laporan-filter-container .action-btn {
            width: 100%;
            justify-content: center;
          }
        }
        .laporan-tab-btn.active.mendesak {
          background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
          color: white;
          box-shadow: 0 4px 15px rgba(239, 68, 68, 0.3);
        }
        .laporan-card-header {
          background: white;
          border-radius: 24px;
          padding: 28px;
          box-shadow: 0 10px 40px -10px rgba(15, 23, 42, 0.08);
          border: 1px solid rgba(226, 232, 240, 0.8);
          position: relative;
          overflow: hidden;
        }
        .laporan-card-header::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 6px;
          background: linear-gradient(90deg, #4f46e5, #ec4899);
          opacity: 0.8;
        }
        .laporan-mendesak-header::before {
          background: linear-gradient(90deg, #ef4444, #f59e0b);
        }
        .laporan-item-card {
          background: #ffffff;
          border: 1px solid #e2e8f0;
          border-radius: 20px;
          padding: 24px;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.03);
          position: relative;
          overflow: hidden;
        }
        .laporan-item-card:hover {
          transform: translateY(-4px);
          box-shadow: 0 12px 25px -5px rgba(0, 0, 0, 0.08);
          border-color: #cbd5e1;
        }
        .status-badge {
          padding: 6px 14px;
          border-radius: 20px;
          font-size: 0.75rem;
          font-weight: 700;
          display: flex;
          align-items: center;
          gap: 6px;
          letter-spacing: 0.3px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.02);
        }
        .action-btn {
          padding: 10px 20px;
          border-radius: 12px;
          font-size: 0.875rem;
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 8px;
          transition: all 0.3s ease;
          border: 1px solid transparent;
          cursor: pointer;
        }
        .action-btn.primary {
          background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
          color: white;
          box-shadow: 0 4px 12px rgba(79, 70, 229, 0.25);
        }
        .action-btn.primary:hover:not(:disabled) {
          box-shadow: 0 6px 16px rgba(79, 70, 229, 0.4);
          transform: translateY(-1px);
        }
        .action-btn.primary:disabled {
          background: #e2e8f0;
          color: #94a3b8;
          box-shadow: none;
          cursor: not-allowed;
        }
        .action-btn.danger {
          background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
          color: white;
          box-shadow: 0 4px 12px rgba(239, 68, 68, 0.25);
        }
        .action-btn.danger:hover {
          box-shadow: 0 6px 16px rgba(239, 68, 68, 0.4);
          transform: translateY(-1px);
        }
        .action-btn.outline {
          background: white;
          border-color: #e2e8f0;
          color: #475569;
        }
        .action-btn.outline:hover {
          background: #f8fafc;
          border-color: #cbd5e1;
          color: #1e293b;
        }
        @media (max-width: 768px) {
          .laporan-filter-container {
            flex-direction: column !important;
            align-items: stretch !important;
          }
          .laporan-filter-item {
            width: 100%;
            justify-content: space-between;
          }
          .laporan-filter-divider {
            display: none !important;
          }
          .laporan-action-group {
            flex-direction: column !important;
            align-items: stretch !important;
            width: 100% !important;
            margin-left: 0 !important;
          }
          .laporan-action-group button, .laporan-action-group .status-badge {
            width: 100% !important;
            justify-content: center;
          }
          .action-btn.outline {
            width: 100% !important;
            justify-content: center;
          }
        }
      `}),(0,_.jsxs)(`div`,{style:{display:`flex`,background:`#f8fafc`,padding:`8px`,borderRadius:`18px`,gap:`8px`,marginBottom:`8px`,border:`1px solid #e2e8f0`,width:`fit-content`,boxShadow:`0 4px 6px -1px rgba(0,0,0,0.02)`},children:[(0,_.jsxs)(`button`,{className:`laporan-tab-btn ${f===`wajib`?`active wajib`:``}`,onClick:()=>h(`wajib`),children:[(0,_.jsx)(c,{size:18}),` Laporan Wajib (Rutin)`]}),(0,_.jsxs)(`button`,{className:`laporan-tab-btn ${f===`mendesak`?`active mendesak`:``}`,onClick:()=>h(`mendesak`),children:[(0,_.jsx)(n,{size:18}),` Laporan Mendesak`]})]}),f===`wajib`&&(0,_.jsx)(`div`,{className:`flex flex-col gap-6`,children:(0,_.jsxs)(`div`,{className:`laporan-card-header`,children:[(0,_.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`flex-start`,marginBottom:`28px`,flexWrap:`wrap`,gap:`20px`},children:[(0,_.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`18px`},children:[(0,_.jsx)(`div`,{style:{width:`56px`,height:`56px`,borderRadius:`16px`,background:`linear-gradient(135deg, rgba(79, 70, 229, 0.1) 0%, rgba(124, 58, 237, 0.1) 100%)`,color:`var(--primary)`,display:`flex`,alignItems:`center`,justifyContent:`center`,boxShadow:`inset 0 2px 4px rgba(255,255,255,0.5)`},children:(0,_.jsx)(c,{size:28,strokeWidth:1.5})}),(0,_.jsxs)(`div`,{children:[(0,_.jsx)(`h2`,{style:{margin:0,fontSize:`1.5rem`,fontWeight:800,color:`var(--text-primary)`,letterSpacing:`-0.5px`},children:`Laporan Wajib Saya`}),(0,_.jsx)(`div`,{style:{fontSize:`0.9rem`,color:`#64748b`,marginTop:`6px`},children:`Kirim dan pantau riwayat laporan rutin Anda`})]})]}),(0,_.jsxs)(`div`,{className:`laporan-filter-container`,style:{display:`flex`,gap:`12px`,alignItems:`center`,flexWrap:`wrap`,background:`#f8fafc`,padding:`12px`,borderRadius:`16px`,border:`1px solid #f1f5f9`},children:[(0,_.jsxs)(`div`,{className:`laporan-filter-item`,style:{display:`flex`,alignItems:`center`,gap:`10px`},children:[(0,_.jsx)(`span`,{style:{fontSize:`0.875rem`,fontWeight:700,color:`#94a3b8`,textTransform:`uppercase`,letterSpacing:`0.5px`},children:`T.A:`}),(0,_.jsx)(`select`,{className:`styled-input`,value:O,onChange:e=>k(Number(e.target.value)),style:{minWidth:`160px`,flex:1,background:`white`,border:`1px solid #e2e8f0`,padding:`8px 12px`},children:z.map(e=>(0,_.jsxs)(`option`,{value:e.id,children:[e.nama_tahun_ajaran,` `,e.is_active?`(Aktif)`:``]},e.id))})]}),(0,_.jsx)(`div`,{className:`laporan-filter-divider`,style:{width:`1px`,height:`32px`,background:`#e2e8f0`,margin:`0 4px`}}),(0,_.jsxs)(`div`,{className:`laporan-filter-item`,style:{display:`flex`,alignItems:`center`,gap:`10px`},children:[(0,_.jsx)(`span`,{style:{fontSize:`0.875rem`,fontWeight:700,color:`#94a3b8`,textTransform:`uppercase`,letterSpacing:`0.5px`},children:`Bulan:`}),(0,_.jsx)(`select`,{className:`styled-input`,value:E,onChange:e=>D(e.target.value),style:{minWidth:`140px`,flex:1,background:`white`,border:`1px solid #e2e8f0`,padding:`8px 12px`},children:ie.map(e=>(0,_.jsx)(`option`,{value:e,children:e},e))})]}),R&&(0,_.jsxs)(`button`,{className:`action-btn outline`,onClick:()=>N(I?.level===`utd`?`utd`:`pjutd`),children:[(0,_.jsx)(o,{size:18}),` Cetak Blanko`]}),R&&O===Y?.id&&(0,_.jsxs)(`div`,{className:`laporan-action-group`,style:{display:`flex`,alignItems:`center`,gap:`12px`,flexWrap:`wrap`,justifyContent:`flex-end`,marginLeft:`auto`},children:[!X&&G&&(0,_.jsxs)(`div`,{className:`status-badge`,style:{padding:`8px 14px`,background:K?`#fef2f2`:`#f8fafc`,color:K?`#ef4444`:`#64748b`,border:`1px solid ${K?`#fecaca`:`#e2e8f0`}`},children:[(0,_.jsx)(i,{size:14}),`Batas: `,new Date(G.batas_tanggal).toLocaleDateString(`id-ID`),` `,K&&`(Terlambat)`]}),(0,_.jsxs)(`button`,{className:`action-btn primary`,onClick:()=>{T({}),y(!0)},disabled:X,children:[(0,_.jsx)(l,{size:18}),X?`Sudah Dilaporkan`:`Isi Laporan`]})]})]})]}),oe?(0,_.jsx)(`p`,{children:`Memuat riwayat...`}):(0,_.jsxs)(`div`,{className:`flex flex-col gap-5`,children:[Z.filter(e=>e.kategori_bulan===E).map(e=>(0,_.jsx)(`div`,{className:`laporan-item-card`,children:(0,_.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`,flexWrap:`wrap`,gap:`16px`},children:[(0,_.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`20px`},children:[(0,_.jsx)(`div`,{style:{background:`rgba(79, 70, 229, 0.08)`,color:`var(--primary)`,padding:`14px`,borderRadius:`16px`},children:(0,_.jsx)(c,{size:28,strokeWidth:1.5})}),(0,_.jsxs)(`div`,{children:[(0,_.jsx)(`div`,{style:{fontWeight:800,color:`var(--text-primary)`,fontSize:`1.25rem`},children:e.kategori_bulan}),(0,_.jsxs)(`div`,{style:{color:`#94a3b8`,fontSize:`0.875rem`,marginTop:`4px`,fontWeight:500},children:[`Dikirim: `,e.bulan_tahun]})]}),e.status_waktu&&(0,_.jsxs)(`span`,{className:`status-badge`,style:{marginLeft:`12px`,background:e.status_waktu===`Tepat Waktu`?`#ecfdf5`:`#fef2f2`,color:e.status_waktu===`Tepat Waktu`?`#10b981`:`#ef4444`,border:`1px solid ${e.status_waktu===`Tepat Waktu`?`#a7f3d0`:`#fecaca`}`},children:[e.status_waktu===`Tepat Waktu`?(0,_.jsx)(r,{size:14}):(0,_.jsx)(n,{size:14}),e.status_waktu]})]}),(0,_.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`16px`},children:[(0,_.jsxs)(`span`,{className:`status-badge`,style:{color:`#10b981`,background:`#ecfdf5`,padding:`10px 16px`,borderRadius:`12px`,border:`1px solid #a7f3d0`},children:[(0,_.jsx)(r,{size:18}),` Terkirim`]}),(0,_.jsxs)(`button`,{className:`action-btn outline`,onClick:()=>j(e),children:[(0,_.jsx)(u,{size:18}),` Cetak`]})]})]})},e.id)),Z.filter(e=>e.kategori_bulan===E).length===0&&(0,_.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,alignItems:`center`,justifyContent:`center`,padding:`48px 24px`,background:`#f8fafc`,borderRadius:`12px`,border:`1px dashed #cbd5e1`},children:[(0,_.jsx)(c,{size:48,style:{color:`#cbd5e1`,marginBottom:`16px`}}),(0,_.jsx)(`h3`,{style:{margin:`0 0 8px 0`,color:`var(--text-primary)`},children:`Belum Ada Laporan`}),(0,_.jsxs)(`p`,{style:{color:`#64748b`,textAlign:`center`,margin:0},children:[`Anda belum mengisi laporan untuk `,E,` pada Tahun Ajaran ini.`]})]})]})]})}),f===`mendesak`&&(0,_.jsxs)(`div`,{className:`laporan-card-header laporan-mendesak-header`,children:[(0,_.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`flex-start`,marginBottom:`28px`,flexWrap:`wrap`,gap:`20px`},children:[(0,_.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`18px`},children:[(0,_.jsx)(`div`,{style:{width:`56px`,height:`56px`,borderRadius:`16px`,background:`linear-gradient(135deg, rgba(239, 68, 68, 0.1) 0%, rgba(245, 158, 11, 0.1) 100%)`,color:`#ef4444`,display:`flex`,alignItems:`center`,justifyContent:`center`,boxShadow:`inset 0 2px 4px rgba(255,255,255,0.5)`},children:(0,_.jsx)(n,{size:28,strokeWidth:1.5})}),(0,_.jsxs)(`div`,{children:[(0,_.jsx)(`h2`,{style:{margin:0,fontSize:`1.5rem`,fontWeight:800,color:`var(--text-primary)`,letterSpacing:`-0.5px`},children:`Laporan Mendesak`}),(0,_.jsx)(`div`,{style:{fontSize:`0.9rem`,color:`#64748b`,marginTop:`6px`},children:`Laporan khusus untuk kejadian luar biasa / insidental`})]})]}),(0,_.jsxs)(`div`,{className:`laporan-filter-container`,style:{display:`flex`,gap:`12px`,alignItems:`center`,flexWrap:`wrap`,background:`#f8fafc`,padding:`12px`,borderRadius:`16px`,border:`1px solid #f1f5f9`},children:[(0,_.jsxs)(`div`,{className:`laporan-filter-item`,style:{display:`flex`,alignItems:`center`,gap:`10px`},children:[(0,_.jsx)(`span`,{style:{fontSize:`0.875rem`,fontWeight:700,color:`#94a3b8`,textTransform:`uppercase`,letterSpacing:`0.5px`},children:`T.A:`}),(0,_.jsx)(`select`,{className:`styled-input`,value:O,onChange:e=>k(Number(e.target.value)),style:{minWidth:`160px`,flex:1,background:`white`,border:`1px solid #e2e8f0`,padding:`8px 12px`},children:z.map(e=>(0,_.jsxs)(`option`,{value:e.id,children:[e.nama_tahun_ajaran,` `,e.is_active?`(Aktif)`:``]},e.id))})]}),R&&O===Y?.id&&(0,_.jsxs)(`div`,{className:`laporan-action-group`,style:{display:`flex`,alignItems:`center`,gap:`12px`,flexWrap:`wrap`,justifyContent:`flex-end`,marginLeft:`auto`},children:[(0,_.jsx)(`div`,{className:`laporan-filter-divider`,style:{width:`1px`,height:`32px`,background:`#e2e8f0`,margin:`0 4px`}}),(0,_.jsxs)(`button`,{className:`action-btn danger`,onClick:()=>x(!0),children:[(0,_.jsx)(n,{size:18}),` Buat Laporan Mendesak`]})]})]})]}),U?(0,_.jsx)(`p`,{children:`Memuat laporan...`}):(0,_.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`16px`},children:[Q.map(e=>(0,_.jsx)(`div`,{className:`laporan-item-card`,style:{background:e.status_penyelesaian===`Selesai`?`#f8fafc`:`white`},children:(0,_.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`flex-start`,marginBottom:`16px`,gap:`16px`},children:[(0,_.jsxs)(`div`,{children:[(0,_.jsx)(`h4`,{style:{margin:`0 0 8px 0`,color:`var(--text-primary)`,fontSize:`1.1rem`},children:e.judul}),(0,_.jsxs)(`div`,{style:{fontSize:`0.875rem`,color:`#94a3b8`,display:`flex`,alignItems:`center`,gap:`6px`},children:[(0,_.jsx)(i,{size:14}),` `,new Date(e.created_at).toLocaleString(`id-ID`)]})]}),(0,_.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`12px`},children:[(0,_.jsx)(`span`,{className:`status-badge`,style:{padding:`6px 12px`,borderRadius:`20px`,fontSize:`0.75rem`,fontWeight:700,background:e.status_penyelesaian===`Menunggu`?`#fee2e2`:e.status_penyelesaian===`Diproses`?`#fef3c7`:`#dcfce7`,color:e.status_penyelesaian===`Menunggu`?`#b91c1c`:e.status_penyelesaian===`Diproses`?`#b45309`:`#15803d`,border:`1px solid ${e.status_penyelesaian===`Menunggu`?`#fecaca`:e.status_penyelesaian===`Diproses`?`#fde68a`:`#bbf7d0`}`,whiteSpace:`nowrap`},children:e.status_penyelesaian}),(0,_.jsxs)(`button`,{className:`action-btn outline`,onClick:()=>j(e),style:{padding:`6px 12px`,fontSize:`0.75rem`},children:[(0,_.jsx)(u,{size:14}),` Cetak`]})]})]})},e.id)),Q.length===0&&(0,_.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,alignItems:`center`,justifyContent:`center`,padding:`48px 24px`,background:`#f8fafc`,borderRadius:`12px`,border:`1px dashed #cbd5e1`},children:[(0,_.jsx)(n,{size:48,style:{color:`#cbd5e1`,marginBottom:`16px`}}),(0,_.jsx)(`h3`,{style:{margin:`0 0 8px 0`,color:`var(--text-primary)`},children:`Belum Ada Laporan Mendesak`}),(0,_.jsx)(`p`,{style:{color:`#64748b`,textAlign:`center`,margin:0},children:`Anda belum membuat laporan mendesak pada Tahun Ajaran ini.`})]})]})]}),(0,_.jsx)(p,{isOpen:v,onClose:()=>y(!1),title:`Isi Laporan Wajib - ${E}`,children:(0,_.jsxs)(`form`,{onSubmit:se,className:`flex flex-col gap-5`,children:[ae?(0,_.jsx)(`p`,{children:`Memuat pertanyaan...`}):B.length===0?(0,_.jsx)(`p`,{children:`Belum ada soal aktif untuk level Anda.`}):B.map(e=>(0,_.jsxs)(`div`,{style:{marginBottom:`16px`},children:[(0,_.jsx)(`h4`,{style:{margin:`0 0 16px 0`,paddingBottom:`8px`,borderBottom:`2px solid var(--primary-color)`,color:`var(--primary-color)`},children:e.nama_kategori}),(0,_.jsxs)(`div`,{className:`flex flex-col gap-5`,children:[e.soal_laporan?.map((e,t)=>(0,_.jsxs)(`div`,{style:{background:`#f8fafc`,padding:`20px`,borderRadius:`12px`,border:`1px solid #e2e8f0`},children:[(0,_.jsxs)(`label`,{style:{display:`block`,fontWeight:600,color:`var(--text-primary)`,marginBottom:`12px`,fontSize:`0.95rem`},children:[t+1,`. `,e.pertanyaan]}),e.tipe_soal===`pilihan_ganda_multi`?(0,_.jsx)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`16px`},children:e.opsi_jawaban?.map((t,n)=>(0,_.jsxs)(`div`,{children:[(0,_.jsx)(`div`,{style:{fontWeight:600,fontSize:`0.85rem`,color:`#64748b`,marginBottom:`8px`},children:t.label}),(0,_.jsx)(`div`,{style:{display:`flex`,flexWrap:`wrap`,gap:`12px`},children:t.options.map((r,i)=>(0,_.jsxs)(`label`,{style:{display:`flex`,alignItems:`center`,gap:`8px`,padding:`8px 12px`,borderRadius:`8px`,border:`1px solid #cbd5e1`,background:`white`,cursor:`pointer`,transition:`all 0.2s`,boxShadow:`0 1px 2px rgba(0,0,0,0.05)`},children:[(0,_.jsx)(`input`,{type:`radio`,name:`soal_${e.id}_group_${n}`,value:r,required:!0,onChange:n=>T({...w,[e.id]:{...w[e.id]||{},[t.label]:n.target.value}}),style:{width:`16px`,height:`16px`,cursor:`pointer`,margin:0}}),(0,_.jsx)(`span`,{style:{fontSize:`0.9rem`,color:`var(--text-primary)`},children:r})]},i))})]},n))}):e.tipe_soal===`uraian`?(0,_.jsx)(`textarea`,{className:`styled-input`,rows:4,required:!0,onChange:t=>T({...w,[e.id]:t.target.value}),placeholder:`Tulis jawaban Anda di sini...`,style:{width:`100%`,resize:`vertical`}}):(0,_.jsx)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`12px`},children:e.opsi_jawaban?.map((t,n)=>(0,_.jsxs)(`label`,{style:{display:`flex`,alignItems:`center`,gap:`12px`,padding:`12px 16px`,borderRadius:`8px`,border:`1px solid #cbd5e1`,background:`white`,cursor:`pointer`,transition:`all 0.2s`,boxShadow:`0 1px 2px rgba(0,0,0,0.05)`},children:[(0,_.jsx)(`input`,{type:`radio`,name:`soal_${e.id}`,value:t,required:!0,onChange:t=>T({...w,[e.id]:t.target.value}),style:{width:`18px`,height:`18px`,cursor:`pointer`,margin:0}}),(0,_.jsx)(`span`,{style:{fontSize:`0.95rem`,color:`var(--text-primary)`},children:t})]},n))})]},e.id)),(!e.soal_laporan||e.soal_laporan.length===0)&&(0,_.jsx)(`p`,{style:{color:`#64748b`,fontSize:`0.875rem`,fontStyle:`italic`},children:`Belum ada soal di kategori ini.`})]})]},e.id)),(0,_.jsxs)(`div`,{style:{display:`flex`,justifyContent:`flex-end`,gap:`12px`,marginTop:`24px`,borderTop:`1px solid #e2e8f0`,paddingTop:`24px`},children:[(0,_.jsx)(`button`,{type:`button`,className:`btn btn-outline`,onClick:()=>y(!1),style:{padding:`8px 16px`,fontSize:`0.875rem`,borderRadius:`8px`,fontWeight:600},children:`Batal`}),(0,_.jsxs)(`button`,{type:`submit`,className:`btn btn-primary`,disabled:B.length===0||q.isPending,style:{padding:`8px 16px`,fontSize:`0.875rem`,borderRadius:`8px`,fontWeight:600,display:`flex`,gap:`8px`,alignItems:`center`},children:[(0,_.jsx)(r,{size:18}),` Kirim Laporan`]})]})]})}),(0,_.jsx)(p,{isOpen:b,onClose:()=>x(!1),title:`Buat Laporan Mendesak`,children:(0,_.jsxs)(`form`,{onSubmit:ce,className:`flex flex-col gap-5`,children:[(0,_.jsxs)(`div`,{children:[(0,_.jsx)(`label`,{style:{display:`block`,fontWeight:600,color:`var(--text-primary)`,marginBottom:`8px`},children:`Judul Masalah / Laporan`}),(0,_.jsx)(`input`,{type:`text`,className:`styled-input`,value:S.judul,onChange:e=>C({...S,judul:e.target.value}),required:!0,placeholder:`Contoh: Atap asrama bocor...`,style:{width:`100%`}})]}),(0,_.jsxs)(`div`,{children:[(0,_.jsx)(`label`,{style:{display:`block`,fontWeight:600,color:`var(--text-primary)`,marginBottom:`8px`},children:`Deskripsi Lengkap`}),(0,_.jsx)(`textarea`,{className:`styled-input`,rows:6,value:S.isi_laporan,onChange:e=>C({...S,isi_laporan:e.target.value}),required:!0,placeholder:`Jelaskan secara detail mengenai kejadian tersebut...`,style:{width:`100%`,resize:`vertical`}})]}),(0,_.jsxs)(`div`,{style:{display:`flex`,justifyContent:`flex-end`,gap:`12px`,marginTop:`16px`,borderTop:`1px solid #e2e8f0`,paddingTop:`24px`},children:[(0,_.jsx)(`button`,{type:`button`,className:`btn btn-outline`,onClick:()=>x(!1),style:{padding:`8px 16px`,fontSize:`0.875rem`,borderRadius:`8px`,fontWeight:600},children:`Batal`}),(0,_.jsxs)(`button`,{type:`submit`,className:`btn btn-primary`,disabled:J.isPending,style:{padding:`8px 16px`,fontSize:`0.875rem`,borderRadius:`8px`,fontWeight:600,background:`#ef4444`,border:`none`,display:`flex`,gap:`8px`,alignItems:`center`},children:[(0,_.jsx)(n,{size:18}),` Kirim Laporan`]})]})]})})]}),(A||M)&&(0,_.jsxs)(`div`,{className:`print-area`,children:[A&&`kategori_bulan`in A&&I?.level===`utd`&&(0,_.jsx)(a,{laporan:A,kopSuratUrl:$(`utd`)}),A&&`kategori_bulan`in A&&I?.level===`pjutd`&&(0,_.jsx)(s,{laporan:A,kopSuratUrl:$(`pjutd`)}),A&&`judul`in A&&(0,_.jsx)(te,{laporan:A,kopSuratUrl:$(I?.level===`utd`?`utd`:`pjutd`)}),M===`utd`&&!A&&(0,_.jsx)(a,{laporan:{user:{fullname:I?.fullname,santri:I?.santri},jawabans:[],kategori_bulan:E},kopSuratUrl:$(`utd`),blankoKategoriList:B}),M===`pjutd`&&!A&&(0,_.jsx)(s,{laporan:{user:{fullname:I?.fullname,pjutd:I?.pjutd},jawabans:[],kategori_bulan:E},kopSuratUrl:$(`pjutd`),blankoKategoriList:B})]})]})};export{v as default};