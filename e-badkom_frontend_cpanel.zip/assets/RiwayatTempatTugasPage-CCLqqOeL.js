import{t as e}from"./useQuery-pglRwBmA.js";import{t}from"./calendar-CRQXuIH0.js";import{t as n}from"./circle-check-big-B8gZywhV.js";import{t as r}from"./map-pin-Cwtu1vSu.js";import{I as i,t as a,v as o}from"./index-BttRe-zx.js";i();var s=o(),c=()=>{let{data:i=[],isLoading:o}=e({queryKey:[`riwayat-tempat-tugas`],queryFn:async()=>(await a.get(`/utd?all_history=true`)).data});return(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`style`,{children:`
        .history-card {
          display: flex;
          align-items: flex-start;
          gap: 20px;
        }
        .history-title-row {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 8px;
          gap: 16px;
        }
        .history-details-row {
          display: flex;
          flex-wrap: wrap;
          gap: 24px;
          color: var(--text-secondary);
          font-size: 0.9rem;
          margin-bottom: 16px;
        }
        @media (max-width: 768px) {
          .history-card {
            flex-direction: column;
            gap: 16px;
          }
          .history-icon {
            width: 48px !important;
            height: 48px !important;
            border-radius: 12px !important;
          }
          .history-icon svg {
            width: 24px;
            height: 24px;
          }
          .history-details-row {
            flex-direction: column;
            gap: 16px;
          }
        }
      `}),(0,s.jsxs)(`div`,{className:`fade-in`,children:[(0,s.jsx)(`div`,{className:`header-actions`,style:{marginBottom:`24px`},children:(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`h2`,{children:`Riwayat Tempat Tugas`}),(0,s.jsx)(`p`,{style:{color:`var(--text-secondary)`},children:`Daftar riwayat lembaga penugasan Anda dari waktu ke waktu.`})]})}),o?(0,s.jsxs)(`div`,{style:{textAlign:`center`,padding:`40px`},children:[(0,s.jsx)(`div`,{className:`spinner`}),(0,s.jsx)(`p`,{style:{marginTop:`16px`,color:`var(--text-secondary)`},children:`Memuat data riwayat...`})]}):(0,s.jsx)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`16px`},children:i.length>0?i.map(e=>(0,s.jsxs)(`div`,{className:`card history-card`,style:{padding:`24px`},children:[(0,s.jsx)(`div`,{className:`history-icon`,style:{width:`60px`,height:`60px`,borderRadius:`16px`,background:`#f1f5f9`,display:`flex`,alignItems:`center`,justifyContent:`center`,color:`var(--primary)`,flexShrink:0},children:(0,s.jsx)(r,{size:28})}),(0,s.jsxs)(`div`,{style:{flex:1,minWidth:0},children:[(0,s.jsxs)(`div`,{className:`history-title-row`,children:[(0,s.jsx)(`h3`,{style:{margin:0,color:`var(--text-primary)`,fontSize:`1.2rem`,lineHeight:`1.3`},children:e.pjutd?.nama_madrasah||e.pjutd?.yayasan||`Nama Lembaga Tidak Tersedia`}),(0,s.jsx)(`span`,{style:{padding:`4px 12px`,borderRadius:`20px`,fontSize:`0.8rem`,fontWeight:600,background:e.status===`Aktif`?`#dcfce7`:`#f1f5f9`,color:e.status===`Aktif`?`#166534`:`#475569`,whiteSpace:`nowrap`},children:e.status})]}),(0,s.jsxs)(`div`,{className:`history-details-row`,children:[(0,s.jsxs)(`div`,{style:{display:`flex`,alignItems:`flex-start`,gap:`8px`},children:[(0,s.jsx)(t,{size:18,style:{marginTop:`2px`,flexShrink:0}}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`span`,{style:{display:`block`,fontSize:`0.75rem`,color:`#94a3b8`,marginBottom:`2px`},children:`Tahun Ajaran`}),(0,s.jsx)(`strong`,{style:{color:`var(--text-primary)`},children:e.tahun_ajaran?.nama_tahun_ajaran})]})]}),(0,s.jsxs)(`div`,{style:{display:`flex`,alignItems:`flex-start`,gap:`8px`},children:[(0,s.jsx)(n,{size:18,style:{marginTop:`2px`,flexShrink:0}}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`span`,{style:{display:`block`,fontSize:`0.75rem`,color:`#94a3b8`,marginBottom:`2px`},children:`Penanggung Jawab`}),(0,s.jsx)(`strong`,{style:{color:`var(--text-primary)`},children:e.pjutd?.nama_pjutd})]})]})]}),(0,s.jsxs)(`div`,{style:{padding:`12px`,background:`#f8fafc`,borderRadius:`8px`,border:`1px solid #e2e8f0`},children:[(0,s.jsx)(`p`,{style:{margin:`0 0 4px 0`,fontSize:`0.85rem`,color:`var(--text-secondary)`,textTransform:`uppercase`,letterSpacing:`0.5px`,fontWeight:600},children:`Alamat Lembaga`}),(0,s.jsx)(`p`,{style:{margin:0,color:`var(--text-primary)`,fontSize:`0.95rem`,lineHeight:`1.4`},children:e.pjutd?.alamat||`Alamat tidak tersedia`})]})]})]},e.id)):(0,s.jsxs)(`div`,{className:`card`,style:{textAlign:`center`,padding:`60px 20px`,color:`var(--text-secondary)`},children:[(0,s.jsx)(r,{size:48,style:{opacity:.2,margin:`0 auto 16px auto`}}),(0,s.jsx)(`h3`,{children:`Belum Ada Riwayat Penugasan`}),(0,s.jsx)(`p`,{children:`Anda belum memiliki riwayat tempat tugas yang terdata di sistem.`})]})})]})]})};export{c as default};